import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import net from 'node:net';
import tls from 'node:tls';
import http from 'node:http';
import https from 'node:https';
import crypto from 'node:crypto';
import events from 'node:events';
import child_process from 'node:child_process';
import url, { fileURLToPath } from 'node:url';
import vm from 'node:vm';
import inspector from 'node:inspector';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
globalThis.__ST_BASE_DIR = __dirname;

// Anti-debug & native integrity guard
if (inspector.url() || process.execArgv.length > 0 || process.env.NODE_OPTIONS) {
  console.error('[GUVENLIK] Hata ayiklayici veya dis enjeksiyon tespit edildi. Calisma durduruldu.');
  process.exit(1);
}
if (!Function.prototype.toString.call(Object.defineProperty).includes('[native code]')) {
  console.error('[GUVENLIK] Calisma zamani butunlugu bozuldu.');
  process.exit(1);
}

const LICENSE_URLS = ["https://api.github.com/repos/ocakciomursel-pixel/stealthtraffic-demo/contents/license-srt1818.json","https://raw.githubusercontent.com/ocakciomursel-pixel/stealthtraffic-demo/main/license-srt1818.json"];

async function verifyRemoteLicense() {
  let lastErr = null;
  for (const u of LICENSE_URLS) {
    try {
      const headers = u.includes('api.github.com')
        ? { 'Accept': 'application/vnd.github.v3.raw', 'User-Agent': 'StealthTraffic-Pro-Loader' }
        : { 'Cache-Control': 'no-cache' };
      const res = await fetch(u + '?t=' + Date.now(), { cache: 'no-store', headers });
      if (!res.ok) continue;
      const lic = await res.json();
      if (!lic || !lic.active || !lic.serverSecret) {
        throw new Error('Demo lisansi yonetici tarafindan kapatildi veya suresi doldu. Tam surum icin iletisime gecin.');
      }
      if (Date.now() > Date.parse(lic.expiresAt)) {
        throw new Error('Demo test suresi sona erdi. Tam acik kaynak surum icin iletisime gecin.');
      }
      return lic;
    } catch (e) {
      lastErr = e;
      if (String(e.message).includes('kapatildi') || String(e.message).includes('sona erdi')) throw e;
    }
  }
  throw lastErr || new Error('Lisans sunucusuna erisilemedi. Internet baglantinizi kontrol edin.');
}

const lic = await verifyRemoteLicense();

// Self-integrity hash: modifying even 1 byte of this file changes selfHash and breaks AES-256-GCM decryption!
const selfText = fs.readFileSync(__filename, 'utf8').replace(/\r\n/g, '\n').trim();
const selfHash = crypto.createHash('sha256').update(selfText, 'utf8').digest('hex');
const envFingerprint = [
  selfHash,
  lic.serverSecret,
  process.execArgv.join(','),
  process.env.NODE_OPTIONS || '',
  String(Boolean(inspector.url()))
].join('|');

const aesKey = crypto.createHash('sha256').update(envFingerprint).digest();
const rawEnc = fs.readFileSync(path.join(__dirname, 'core.enc'));
const iv = rawEnc.subarray(0, 12);
const authTag = rawEnc.subarray(12, 28);
const ciphertext = rawEnc.subarray(28);

let plainBuf;
try {
  const decipher = crypto.createDecipheriv('aes-256-gcm', aesKey, iv);
  decipher.setAuthTag(authTag);
  plainBuf = Buffer.concat([decipher.update(ciphertext), decipher.final()]);
  aesKey.fill(0);
} catch {
  console.error('[GUVENLIK] Sifreli cekirdek dogrulanamadi veya dosya butunlugu bozuldu.');
  process.exit(1);
}

// Compile strictly in V8 RAM and immediately wipe plaintext buffer from memory
const script = new vm.Script(plainBuf.toString('utf8'), { filename: 'stealthtraffic-core.vm' });
plainBuf.fill(0);
const entryFn = script.runInThisContext();
await entryFn({ http, https, net, tls, fs, path, os, crypto, url, events, child_process });

// 30-second remote kill-switch heartbeat
setInterval(async () => {
  try {
    if (inspector.url()) throw new Error('Debugger attached');
    await verifyRemoteLicense();
  } catch (err) {
    console.error('\n[LISANS] ' + err.message);
    process.exit(1);
  }
}, 30_000);
