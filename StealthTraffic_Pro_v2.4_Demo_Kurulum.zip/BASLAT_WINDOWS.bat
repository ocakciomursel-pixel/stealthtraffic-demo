@echo off
title StealthTraffic Pro v2.4 - Canli Demo Sunucusu
echo ===============================================================
echo   StealthTraffic Pro v2.4 (Sifreli Demo Cekirdegi) Baslatiliyor...
echo ===============================================================
node trial-loader.mjs
pause
