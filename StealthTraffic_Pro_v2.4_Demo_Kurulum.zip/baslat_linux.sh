#!/usr/bin/env bash
echo "StealthTraffic Pro v2.4 Baslatiliyor..."
node trial-loader.mjs
