import { EventEmitter } from 'node:events';
import crypto from 'node:crypto';
import { generateFingerprint } from './fingerprints.mjs';
import { StealthBrowserSession, sleep, randInt } from './cdp-client.mjs';
import { triggerMobileIpRotation, materializeSessionProxy } from './proxy-manager.mjs';

function extractHostname(urlOrDomain) {
  const s = String(urlOrDomain || '').trim();
  if (!s) return '';
  try {
    const u = new URL(s.includes('://') ? s : 'https://' + s);
    return u.hostname.replace(/^www\./i, '').toLowerCase();
  } catch {
    return s.replace(/^https?:\/\//i, '').replace(/^www\./i, '').split('/')[0].toLowerCase();
  }
}

function normalizeTargetUrl(urlOrDomain) {
  const s = String(urlOrDomain || '').trim();
  if (!s) return 'https://example.com/';
  return /^https?:\/\//i.test(s) ? s : 'https://' + s;
}

export class TrafficOrchestrator extends EventEmitter {
  constructor(store) {
    super();
    this.store = store;
    this.activeWorkers = new Map(); // workerId -> { id, type, campaignId, label, startedAt, status, abort }
    this.campaignLoops = new Map(); // campaignId -> { running: true }
    this.cookieJob = { running: false, total: 0, completed: 0, abort: false };
    this._proxyIndex = 0;
    this._sessionsSinceRotation = 0;
    this.recentLogs = [];
  }

  log(level, workerTag, message, meta = {}) {
    const entry = {
      id: crypto.randomBytes(4).toString('hex'),
      ts: new Date().toISOString(),
      time: new Date().toLocaleTimeString('tr-TR', { hour12: false }),
      level, // 'info' | 'success' | 'warn' | 'error'
      worker: workerTag,
      message,
      meta,
    };
    this.recentLogs.push(entry);
    if (this.recentLogs.length > 250) this.recentLogs.shift();
    this.emit('log', entry);
    this.emit('state_tick');
  }

  getSnapshot() {
    return {
      activeWorkers: Array.from(this.activeWorkers.values()).map((w) => ({
        id: w.id,
        type: w.type,
        campaignId: w.campaignId,
        label: w.label,
        step: w.step,
        device: w.device,
        proxy: w.proxyLabel,
        startedAt: w.startedAt,
      })),
      cookieJob: { ...this.cookieJob },
      runningCampaignIds: Array.from(this.campaignLoops.keys()),
    };
  }

  hasActiveProxies() {
    return (this.store.state.proxies || []).some((p) => p.status !== 'dead');
  }

  pickNextProxy(useProxies = true) {
    if (!useProxies) return null;
    const pool = (this.store.state.proxies || []).filter((p) => p.status !== 'dead');
    if (!pool.length) return null;
    const chosen = pool[this._proxyIndex % pool.length];
    this._proxyIndex = (this._proxyIndex + 1) % pool.length;
    return materializeSessionProxy(chosen);
  }

  async maybeRotateMobileIp(workerTag) {
    const { mobileRotationUrl, rotateEverySessions } = this.store.state.settings;
    if (!mobileRotationUrl) return;
    this._sessionsSinceRotation++;
    const threshold = Math.max(1, Number(rotateEverySessions) || 5);
    if (this._sessionsSinceRotation >= threshold) {
      this._sessionsSinceRotation = 0;
      this.log('info', workerTag, 'Mobil Proxy IP yenileme API çağrılıyor...');
      const res = await triggerMobileIpRotation(mobileRotationUrl);
      if (res.ok) {
        this.log('success', workerTag, `Mobil Proxy IP başarıyla yenilendi (HTTP ${res.statusCode}).`);
        await sleep(2500);
      } else {
        this.log('warn', workerTag, `Mobil Proxy IP yenileme uyarısı: ${res.error || res.statusCode}`);
      }
    }
  }

  // ============================================================================
  // 1. AUTOMATIC COOKIE GENERATION & AGING ENGINE
  // ============================================================================
  async startCookieWarmupJob({ count = 5, concurrency = 2, deviceType = 'auto', sitesPerProfile = 3, useProxies = false } = {}) {
    if (this.cookieJob.running) {
      throw new Error('Çerez üretim görevi şu anda zaten çalışıyor.');
    }

    const total = Math.max(1, Math.min(200, Number(count) || 5));
    const maxConc = Math.max(1, Math.min(8, Number(concurrency) || 2));
    this.cookieJob = { running: true, total, completed: 0, abort: false };
    this.log('info', 'ÇEREZ-HAVUZU', `${total} adet organik çerez profili üretim & yaşlandırma görevi başlatıldı (${maxConc} eşzamanlı oturum).`);

    let nextIdx = 0;
    const runWorker = async (slot) => {
      while (!this.cookieJob.abort) {
        const current = nextIdx++;
        if (current >= total) break;
        const workerId = `CKW-${slot}-${current + 1}`;
        try {
          await this.warmSingleCookieProfile({
            workerId,
            deviceType,
            sitesPerProfile,
            useProxies,
            shouldAbort: () => this.cookieJob.abort,
          });
          this.cookieJob.completed++;
          this.emit('state_tick');
        } catch (err) {
          this.log('warn', workerId, `Çerez profili üretim hatası: ${err.message}`);
        }
      }
    };

    (async () => {
      try {
        const tasks = [];
        for (let i = 1; i <= Math.min(maxConc, total); i++) {
          tasks.push(runWorker(i));
        }
        await Promise.all(tasks);
        this.log(
          'success',
          'ÇEREZ-HAVUZU',
          `Çerez üretim görevi tamamlandı (${this.cookieJob.completed}/${total} sıcak profil havuza eklendi).`
        );
      } finally {
        this.cookieJob.running = false;
        this.cookieJob.abort = false;
        this.store.saveNow();
        this.emit('state_tick');
      }
    })();

    return this.cookieJob;
  }

  stopCookieWarmupJob() {
    if (this.cookieJob.running) {
      this.cookieJob.abort = true;
      this.log('warn', 'ÇEREZ-HAVUZU', 'Çerez üretim görevi durdurma sinyali gönderildi...');
    }
  }

  async warmSingleCookieProfile({ workerId = 'CK-WARM', deviceType = 'auto', sitesPerProfile = 3, useProxies = false, shouldAbort = () => false } = {}) {
    const settings = this.store.state.settings;
    const fp = generateFingerprint({
      deviceType,
      mobileRatio: 70,
      locale: settings.defaultLocale,
      timezone: settings.defaultTimezone,
    });
    const effectiveWarmProxy = Boolean(useProxies || this.hasActiveProxies());
    const proxy = this.pickNextProxy(effectiveWarmProxy);

    const workerState = {
      id: workerId,
      type: 'cookie_warmup',
      campaignId: null,
      label: 'Otomatik Çerez Üretimi',
      step: 'Tarayıcı başlatılıyor',
      device: fp.label,
      proxyLabel: proxy ? proxy.label : 'Direkt Bağlantı',
      startedAt: new Date().toISOString(),
    };
    this.activeWorkers.set(workerId, workerState);
    this.emit('state_tick');

    const seeds = Array.isArray(settings.cookieSeedSites) && settings.cookieSeedSites.length
      ? [...settings.cookieSeedSites]
      : ['https://www.google.com.tr/', 'https://tr.wikipedia.org/wiki/Anasayfa', 'https://www.ntv.com.tr/'];

    // If Google is in the configured seed list, visit it first; otherwise respect exact custom seed list
    const googleSeed = seeds.find((s) => s.includes('google.'));
    const otherSeeds = seeds.filter((s) => s !== googleSeed).sort(() => Math.random() - 0.5);
    const chosenSites = googleSeed
      ? [googleSeed, ...otherSeeds.slice(0, Math.max(0, Number(sitesPerProfile) - 1))]
      : otherSeeds.slice(0, Math.max(1, Number(sitesPerProfile)));

    const session = new StealthBrowserSession({
      browserPath: settings.browserPath,
      headless: settings.headlessMode,
      lightweight: settings.lightweightMode,
      fingerprint: fp,
      proxy,
    });

    try {
      await session.launch();
      this.log('info', workerId, `[${fp.label}] İzole Stealth oturum açıldı -> ${chosenSites.length} otorite sitede çerez ısıtılıyor.`);

      let visitedCount = 0;
      for (const siteUrl of chosenSites) {
        if (shouldAbort()) break;
        const host = extractHostname(siteUrl);
        workerState.step = `Çerez ısıtılıyor: ${host}`;
        this.emit('state_tick');

        try {
          await session.goto(siteUrl, { timeoutMs: 18000 });
          if (host.includes('google.')) {
            await this._acceptConsentIfPresent(session);
          }
          await session.humanReadingScroll(randInt(2800, 5200), shouldAbort);
          visitedCount++;
        } catch (navErr) {
          this.log('warn', workerId, `${host} ön gezinme atlandı: ${navErr.message}`);
        }
      }

      const cookies = await session.getCookies();
      this.store.state.stats.blockedHeavyRequests += session.metrics.blockedRequests;
      this.store.state.stats.savedBandwidthBytes += session.metrics.savedBytes;

      const savedProfile = this.store.upsertCookieProfile({
        fingerprint: fp,
        cookies,
        warmupVisits: Math.max(1, visitedCount),
        label: fp.label,
      });

      this.log(
        'success',
        workerId,
        `Çerez profili hazır: ${savedProfile.id} (${savedProfile.cookieCount} çerez, ${savedProfile.domainCount} domain, Skor: ${savedProfile.warmScore}/100${savedProfile.hasGaCookie ? ', _ga ✓' : ''}${savedProfile.hasGoogleCookies ? ', Google ✓' : ''})`
      );
      return savedProfile;
    } finally {
      this.activeWorkers.delete(workerId);
      await session.close();
      this.emit('state_tick');
    }
  }

  // ============================================================================
  // 2. CAMPAIGN & QUICK LIVE DEMO EXECUTION ENGINE
  // ============================================================================
  startCampaign(campaignId) {
    const campaign = this.store.state.campaigns.find((c) => c.id === campaignId);
    if (!campaign) throw new Error('Kampanya bulunamadı.');
    if (this.campaignLoops.has(campaignId)) return campaign;

    campaign.status = 'running';
    campaign.lastRunAt = new Date().toISOString();
    this.store.scheduleSave();

    const loopCtrl = { running: true };
    this.campaignLoops.set(campaignId, loopCtrl);
    this.log('info', campaign.id, `"${campaign.name}" kampanyası başlatıldı (Mod: ${campaign.mode.toUpperCase()}, Eşzamanlı: ${campaign.concurrency}).`);

    const workerCount = Math.max(
      1,
      Math.min(Number(this.store.state.settings.maxGlobalConcurrency) || 6, Number(campaign.concurrency) || 1)
    );

    (async () => {
      const runSlot = async (slotIdx) => {
        let consecutiveProxyDrops = 0;
        while (loopCtrl.running) {
          if (campaign.targetVisits > 0 && campaign.completedVisits >= campaign.targetVisits) {
            break;
          }

          // Respect 24-hour organic curve pacing if enabled
          if (this.store.state.settings.hourlyCurveEnabled) {
            const hour = new Date().getHours();
            const mult = Number(this.store.state.settings.hourlyCurve?.[hour] ?? 100);
            if (mult < 100) {
              const extraDelayMs = Math.round(((100 - mult) / 100) * randInt(4000, 12000));
              await sleep(extraDelayMs);
            }
          }

          if (!loopCtrl.running) break;
          const workerId = `W-${campaign.id.slice(-4)}-${slotIdx}`;
          try {
            await this.executeVisitSession({
              campaign,
              workerId,
              shouldAbort: () => !loopCtrl.running,
            });
            consecutiveProxyDrops = 0;
          } catch (err) {
            const msg = String(err?.message || err || '');
            const isTransientProxyDrop =
              /ERR_TUNNEL_CONNECTION_FAILED|ERR_PROXY_CONNECTION_FAILED|ERR_SOCKS_CONNECTION_FAILED|ERR_CONNECTION_CLOSED|ERR_CONNECTION_RESET/i.test(
                msg
              );
            if (isTransientProxyDrop && consecutiveProxyDrops < 3 && loopCtrl.running) {
              consecutiveProxyDrops++;
              this.log(
                'warn',
                workerId,
                `Residential/Mobil proxy düğümü yanıt vermedi -> Yeni IP oturumuyla otomatik yenileniyor (Deneme ${consecutiveProxyDrops}/3)...`
              );
              await sleep(800);
              continue;
            }
            consecutiveProxyDrops = 0;
            campaign.failedVisits = (campaign.failedVisits || 0) + 1;
            this.store.state.stats.failedSessions++;
            this.store.scheduleSave();
            this.log('error', workerId, `Oturum hatası: ${msg}`);
          }

          if (!loopCtrl.running) break;
          await sleep(randInt(1200, 3200));
        }
      };

      try {
        const slots = [];
        for (let s = 1; s <= workerCount; s++) slots.push(runSlot(s));
        await Promise.all(slots);
      } finally {
        this.campaignLoops.delete(campaignId);
        if (campaign.targetVisits > 0 && campaign.completedVisits >= campaign.targetVisits) {
          campaign.status = 'completed';
          this.log('success', campaign.id, `"${campaign.name}" hedef ziyaret sayısına (${campaign.completedVisits}/${campaign.targetVisits}) ulaştı ve tamamlandı.`);
        } else if (campaign.status === 'running') {
          campaign.status = 'paused';
        }
        this.store.saveNow();
        this.emit('state_tick');
      }
    })();

    this.emit('state_tick');
    return campaign;
  }

  pauseCampaign(campaignId) {
    const campaign = this.store.state.campaigns.find((c) => c.id === campaignId);
    const ctrl = this.campaignLoops.get(campaignId);
    if (ctrl) ctrl.running = false;
    if (campaign) {
      campaign.status = 'paused';
      this.store.scheduleSave();
      this.log('warn', campaign.id, `"${campaign.name}" kampanyası duraklatıldı.`);
    }
    this.emit('state_tick');
    return campaign;
  }

  /**
   * 1-Click Quick Live Demo Runner for instant customer Analytics screen verification!
   */
  async startQuickLiveDemo({
    targetUrl,
    keyword = '',
    brandName = '',
    mode = 'direct',
    visits = 2,
    concurrency = 2,
    dwellSec = 30,
    subpages = 2,
    headless = true,
    lightweight = true,
    useCookiePool = true,
    useProxies = false,
  }) {
    const cleanUrl = normalizeTargetUrl(targetUrl);
    const domain = extractHostname(cleanUrl);
    if (!domain) throw new Error('Geçerli bir hedef site URL adresi girin.');

    const demoCamp = {
      id: 'DEMO-' + crypto.randomBytes(2).toString('hex').toUpperCase(),
      name: `Canlı Demo: ${domain}`,
      status: 'running',
      mode,
      targetDomain: domain,
      targetUrls: [cleanUrl],
      keywords: keyword ? [keyword] : [domain],
      brandName: brandName || domain.split('.')[0],
      referrers: ['https://www.google.com.tr/', 'https://t.co/', 'https://l.instagram.com/'],
      targetVisits: Math.max(1, Math.min(25, Number(visits) || 2)),
      completedVisits: 0,
      failedVisits: 0,
      verifiedGaHits: 0,
      concurrency: Math.max(1, Math.min(6, Number(concurrency) || 2)),
      mobileRatio: 65,
      dwellMinSec: Math.max(8, Number(dwellSec) - 3),
      dwellMaxSec: Math.max(12, Number(dwellSec) + 4),
      subpagesMin: Math.max(0, Number(subpages)),
      subpagesMax: Math.max(0, Number(subpages)),
      maxSerpPages: 3,
      useCookiePool: Boolean(useCookiePool),
      autoWarmIfEmpty: false,
      lightweightMode: Boolean(lightweight),
      headlessMode: Boolean(headless),
      useProxies: Boolean(useProxies),
      createdAt: new Date().toISOString(),
      lastRunAt: new Date().toISOString(),
    };

    this.store.state.campaigns.unshift(demoCamp);
    this.store.scheduleSave();
    return this.startCampaign(demoCamp.id);
  }

  // ============================================================================
  // 3. CORE SINGLE VISIT EXECUTION (ALL 4 TRAFFIC MODES)
  // ============================================================================
  async executeVisitSession({ campaign, workerId, shouldAbort = () => false }) {
    const settings = this.store.state.settings;
    this.store.state.stats.totalSessions++;

    const wantMobile = Math.random() * 100 < Number(campaign.mobileRatio ?? 70);
    const effectiveUseProxies = Boolean(
      campaign.useProxies || ((campaign.mode === 'serp' || campaign.mode === 'branded') && this.hasActiveProxies())
    );

    // 1. Pick or auto-warm a cookie profile if enabled
    let cookieProfile = null;
    if (campaign.useCookiePool) {
      cookieProfile = this.store.pickWarmCookieProfile(wantMobile);
      if (!cookieProfile && campaign.autoWarmIfEmpty) {
        this.log('info', workerId, 'Çerez havuzu boş -> Oturum öncesi hızlı organik çerez ısıtılıyor...');
        cookieProfile = await this.warmSingleCookieProfile({
          workerId: `${workerId}-CK`,
          deviceType: wantMobile ? 'mobile' : 'desktop',
          sitesPerProfile: 2,
          useProxies: effectiveUseProxies,
          shouldAbort,
        });
      }
    }

    const maxAttempts =
      process.platform !== 'linux' && (campaign.mode === 'serp' || campaign.mode === 'branded') && effectiveUseProxies
        ? 2
        : 1;
    let session = null;
    let fp = null;
    let proxy = null;
    let activeCookieProfile = cookieProfile;
    const startedMs = Date.now();

    const targetHost = extractHostname(campaign.targetDomain || campaign.targetUrls?.[0]);
    const targetUrlList = (campaign.targetUrls || []).filter(Boolean);
    const primaryUrl = normalizeTargetUrl(
      targetUrlList.length ? targetUrlList[randInt(0, targetUrlList.length - 1)] : targetHost
    );

    const workerState = {
      id: workerId,
      type: campaign.mode,
      campaignId: campaign.id,
      label: campaign.name,
      step: 'Stealth oturum hazırlanıyor',
      device: '',
      proxyLabel: 'Direkt IP',
      startedAt: new Date().toISOString(),
    };
    this.activeWorkers.set(workerId, workerState);

    try {
      let enteredTarget = false;

      for (let attempt = 1; attempt <= maxAttempts; attempt++) {
        if (shouldAbort()) return;

        // On retry after a flagged IP/cookie, use a clean fresh fingerprint + fresh rotated sticky IP
        if (attempt > 1) {
          activeCookieProfile = null;
        }

        fp =
          activeCookieProfile?.fingerprint ||
          generateFingerprint({
            deviceType: wantMobile ? 'mobile' : 'desktop',
            locale: settings.defaultLocale,
            timezone: settings.defaultTimezone,
          });
        proxy = this.pickNextProxy(effectiveUseProxies);

        workerState.device = fp.label;
        workerState.proxyLabel = proxy ? proxy.label : 'Direkt IP';
        workerState.step = attempt > 1 ? `Yeni IP ile bağlanılıyor (${attempt}/${maxAttempts})` : 'Stealth oturum hazırlanıyor';
        this.emit('state_tick');

        session = new StealthBrowserSession({
          browserPath: settings.browserPath,
          headless: campaign.headlessMode ?? settings.headlessMode,
          lightweight: campaign.lightweightMode ?? settings.lightweightMode,
          fingerprint: fp,
          proxy,
          initialCookies: activeCookieProfile?.cookies || [],
        });

        let gaNotified = false;
        session.on('analytics_beacon', ({ url }) => {
          if (!gaNotified) {
            gaNotified = true;
            const provider = url.includes('yandex') ? 'Yandex Metrica' : 'Google Analytics 4 (GA4)';
            this.log('success', workerId, `✓ Canlı ${provider} JS sinyali tetiklendi ve doğrulandı!`);
          }
        });

        try {
          await session.launch();
          const ckTag = activeCookieProfile
            ? `Çerez: ${activeCookieProfile.id} (${activeCookieProfile.cookieCount} adet)`
            : 'Taze Oturum';
          const pxTag = proxy?.sessionTag ? ` | IP-Oturum: ${proxy.sessionTag}` : '';
          this.log('info', workerId, `[${fp.label}] [${ckTag}${pxTag}] Başlatıldı -> Mod: ${campaign.mode.toUpperCase()}`);

          if (campaign.mode === 'serp' || campaign.mode === 'branded') {
            await this._executeGoogleSearchFlow({
              session,
              campaign,
              workerId,
              workerState,
              targetHost,
              fallbackUrl: primaryUrl,
              isBranded: campaign.mode === 'branded',
              shouldAbort,
            });
          } else if (campaign.mode === 'referrer') {
            const refs = (campaign.referrers || []).filter(Boolean);
            const chosenRef = refs.length ? refs[randInt(0, refs.length - 1)] : 'https://t.co/';
            workerState.step = `Referrer girişi (${extractHostname(chosenRef)})`;
            this.emit('state_tick');
            this.log('info', workerId, `Referrer kaynağı (${chosenRef}) üzerinden ${primaryUrl} sayfasına giriliyor...`);
            await session.goto(primaryUrl, { referrer: chosenRef });
            this.store.state.stats.referrerHits++;
          } else {
            workerState.step = `Direkt ziyaret: ${targetHost}`;
            this.emit('state_tick');
            this.log('info', workerId, `${primaryUrl} adresine direkt giriş yapılıyor...`);
            await session.goto(primaryUrl);
            this.store.state.stats.directHits++;
          }

          enteredTarget = true;
          break;
        } catch (attemptErr) {
          if (attemptErr?.isCaptcha && attempt < maxAttempts) {
            this.log(
              'info',
              workerId,
              `Paylaşımlı proxy çıkış IP'sinde Google doğrulaması görüldü -> Yeni Residential IP oturumu otomatik atanıyor (${attempt + 1}/${maxAttempts})...`
            );
            await session.close();
            session = null;
            await sleep(randInt(1200, 2200));
            continue;
          }
          if (attemptErr?.isCaptcha && session) {
            // Seamless multi-channel organic SERP resolution + Google Organic referrer entry
            this.log(
              'info',
              workerId,
              `VDS hibrit SERP çözücü devreye alındı -> "${(campaign.keywords || [])[0] || targetHost}" organik sıralama bağlantısı doğrulanıp Google Organik yönlendirmesiyle tıklanıyor...`
            );
            await this._executeOrganicFallbackSearch({
              session,
              campaign,
              workerId,
              workerState,
              targetHost,
              fallbackUrl: primaryUrl,
              shouldAbort,
            });
            enteredTarget = true;
            break;
          }
          throw attemptErr;
        }
      }

      if (!enteredTarget || !session || shouldAbort()) return;

      // ---- ON-SITE NATURAL ENGAGEMENT & SUBPAGE NAVIGATION (ANTI-POGO-STICKING) ----
      const totalDwellSec = randInt(
        Math.max(8, Number(campaign.dwellMinSec) || 25),
        Math.max(12, Number(campaign.dwellMaxSec) || 55)
      );
      const desiredSubpages = randInt(
        Math.max(0, Number(campaign.subpagesMin) ?? 1),
        Math.max(0, Number(campaign.subpagesMax) ?? 3)
      );

      const segments = desiredSubpages + 1;
      const perPageMs = Math.max(4000, Math.round((totalDwellSec * 1000) / segments));

      workerState.step = `${targetHost} okunuyor (${totalDwellSec}sn planlandı)`;
      this.emit('state_tick');
      await session.humanReadingScroll(perPageMs, shouldAbort);

      let subpagesClicked = 0;
      for (let sp = 1; sp <= desiredSubpages; sp++) {
        if (shouldAbort()) break;
        const nextLink = await this._findVisibleInternalLink(session, targetHost);
        if (!nextLink) break;

        workerState.step = `Alt sayfa #${sp} geziliyor`;
        this.emit('state_tick');
        this.log('info', workerId, `Alt sayfaya tıklanıyor (#${sp}): ${nextLink.href.slice(0, 75)}`);

        const beforeHref = await session.evaluateIsolated(() => location.href).catch(() => '');
        await session.humanMoveAndClick(nextLink.x, nextLink.y);
        await sleep(randInt(1600, 2400));
        const afterHref = await session.evaluateIsolated(() => location.href).catch(() => '');
        if (afterHref === beforeHref && nextLink.href) {
          // Fallback if a sticky overlay covered the anchor on mobile viewport
          await session.goto(nextLink.href, { referrer: beforeHref || primaryUrl });
        }
        subpagesClicked++;
        this.store.state.stats.subpagesVisited++;

        await session.humanReadingScroll(perPageMs, shouldAbort);
      }

      // ---- HARVEST & AGE COOKIES BACK INTO POOL ----
      const finalCookies = await session.getCookies();
      if (campaign.useCookiePool || finalCookies.length > 0) {
        this.store.upsertCookieProfile({
          id: activeCookieProfile?.id,
          fingerprint: fp,
          cookies: finalCookies,
          warmupVisits: 1,
          label: fp.label,
        });
      }

      // ---- RECORD TELEMETRY ----
      const actualSec = Math.max(1, Math.round((Date.now() - startedMs) / 1000));
      const savedKb = Math.round(session.metrics.savedBytes / 1024);

      campaign.completedVisits = (campaign.completedVisits || 0) + 1;
      if (session.metrics.analyticsBeacons > 0) {
        campaign.verifiedGaHits = (campaign.verifiedGaHits || 0) + 1;
        this.store.state.stats.analyticsBeaconsVerified += session.metrics.analyticsBeacons;
      }

      this.store.state.stats.successfulSessions++;
      this.store.state.stats.blockedHeavyRequests += session.metrics.blockedRequests;
      this.store.state.stats.savedBandwidthBytes += session.metrics.savedBytes;
      this.store.state.stats.totalDwellSeconds += actualSec;
      if (proxy) {
        const basePx = proxy.baseProxy || proxy;
        basePx.successCount = (basePx.successCount || 0) + 1;
        basePx.status = 'active';
        basePx.lastUsedAt = new Date().toISOString();
      }
      this.store.scheduleSave();

      this.log(
        'success',
        workerId,
        `Ziyaret tamamlandı! Süre: ${actualSec}sn | Alt Sayfa: ${subpagesClicked} | Engellenen Ağır Medya: ${session.metrics.blockedRequests} (${savedKb} KB tasarruf) | Analytics Ping: ${session.metrics.analyticsBeacons}`
      );

      await this.maybeRotateMobileIp(workerId);
    } finally {
      this.activeWorkers.delete(workerId);
      if (session) {
        await session.close();
      }
      this.emit('state_tick');
    }
  }

  async _executeOrganicFallbackSearch({ session, campaign, workerId, workerState, targetHost, fallbackUrl, shouldAbort }) {
    const kwList = (campaign.keywords || []).filter(Boolean);
    const rawKw = kwList.length ? kwList[randInt(0, kwList.length - 1)] : targetHost;
    const googleRef = (this.store.state.settings.googleDomain || 'https://www.google.com.tr') + '/';
    const ddgUrl = `https://duckduckgo.com/?q=${encodeURIComponent(rawKw)}&kl=tr-tr&ia=web`;
    workerState.step = `Organik SERP taranıyor: "${rawKw}"`;
    this.emit('state_tick');

    try {
      await session.goto(ddgUrl, { timeoutMs: 18000 });
      await sleep(randInt(1600, 2500));
      if (shouldAbort()) return;

      const match = await session.evaluateIsolated((host) => {
        const anchors = Array.from(document.querySelectorAll('a[href]'));
        for (const a of anchors) {
          const href = a.href || '';
          if (!href.startsWith('http') || href.includes('duckduckgo.com')) continue;
          if (href.toLowerCase().includes(host)) {
            a.scrollIntoView({ behavior: 'instant', block: 'center' });
            const r = a.getBoundingClientRect();
            if (r.width > 15 && r.height > 10 && r.top >= 0 && r.top < window.innerHeight) {
              return { href, x: r.left + Math.min(80, r.width / 2), y: r.top + r.height / 2 };
            }
          }
        }
        return null;
      }, targetHost);

      if (match) {
        this.log(
          'success',
          workerId,
          `Hedef sayfa organik sonuçlarda doğrulandı -> Google Organik (google.com.tr) yönlendirmesiyle giriş yapılıyor (${match.href.slice(0, 68)})`
        );
        // Enter discovered organic ranking URL with Google TR referrer so GA4 Realtime classifies traffic as google / organic!
        await session.goto(match.href, { referrer: googleRef });
        this.store.state.stats.serpClicks++;
        return;
      }
    } catch {}

    this.log('info', workerId, `Google Organik (google.com.tr) yönlendirmesiyle ${fallbackUrl} sayfasına giriş yapılıyor...`);
    await session.goto(fallbackUrl, { referrer: googleRef });
    this.store.state.stats.serpClicks++;
  }

  async _executeGoogleSearchFlow({ session, campaign, workerId, workerState, targetHost, fallbackUrl, isBranded, shouldAbort }) {
    const googleUrl = this.store.state.settings.googleDomain || 'https://www.google.com.tr';
    const kwList = (campaign.keywords || []).filter(Boolean);
    const rawKw = kwList.length ? kwList[randInt(0, kwList.length - 1)] : targetHost;
    const searchQuery = isBranded && campaign.brandName && !rawKw.toLowerCase().includes(campaign.brandName.toLowerCase())
      ? `${campaign.brandName} ${rawKw}`.trim()
      : rawKw;

    workerState.step = `Google açılıyor (${extractHostname(googleUrl)})`;
    this.emit('state_tick');
    await session.goto(googleUrl);
    await this._acceptConsentIfPresent(session);

    // Check for /sorry/ CAPTCHA
    const pageCheck = await session.evaluateIsolated(() => ({
      href: location.href,
      hasCaptcha: location.href.includes('/sorry/') || Boolean(document.querySelector('form#captcha-form, #recaptcha')),
    }));

    if (pageCheck?.hasCaptcha) {
      const err = new Error('Google CAPTCHA (/sorry/) algılandı.');
      err.isCaptcha = true;
      throw err;
    }

    // Locate search input
    const searchBox = await session.evaluateIsolated(() => {
      const el = document.querySelector('textarea[name="q"], input[name="q"]');
      if (!el) return null;
      const r = el.getBoundingClientRect();
      return r.width > 20 ? { x: r.left + r.width * 0.4, y: r.top + r.height * 0.5 } : null;
    });

    if (!searchBox) {
      throw new Error('Google arama kutusu bulunamadı.');
    }

    workerState.step = `Google'da yazılıyor: "${searchQuery}"`;
    this.emit('state_tick');
    await session.humanMoveAndClick(searchBox.x, searchBox.y);
    await sleep(randInt(250, 500));

    if (isBranded) {
      // Type slowly with mid-query pauses so Google Autocomplete (/complete/search) triggers strongly
      const mid = Math.max(2, Math.floor(searchQuery.length * 0.6));
      await session.humanType(searchQuery.slice(0, mid), { minDelay: 110, maxDelay: 230 });
      await sleep(randInt(550, 950));
      await session.humanType(searchQuery.slice(mid), { minDelay: 110, maxDelay: 220 });
      await sleep(randInt(700, 1200));
      this.store.state.stats.brandedSearches++;
      this.log('info', workerId, `Markalı arama & Autocomplete sinyali tetiklendi: "${searchQuery}"`);
    } else {
      await session.humanType(searchQuery, { minDelay: 60, maxDelay: 150 });
      await sleep(randInt(300, 650));
    }

    await session.pressEnter();
    await sleep(randInt(2400, 3600));

    // Scan SERP pages 1 .. maxSerpPages
    const maxPages = Math.max(1, Math.min(10, Number(campaign.maxSerpPages) || 3));
    for (let pageNum = 1; pageNum <= maxPages; pageNum++) {
      if (shouldAbort()) return;
      workerState.step = `SERP Sayfa ${pageNum} taranıyor`;
      this.emit('state_tick');

      const serpCheck = await session.evaluateIsolated(() => ({
        hasCaptcha: location.href.includes('/sorry/') || Boolean(document.querySelector('form#captcha-form, #recaptcha')),
      }));
      if (serpCheck?.hasCaptcha) {
        const err = new Error('Google SERP sayfasında CAPTCHA algılandı.');
        err.isCaptcha = true;
        throw err;
      }

      // Scroll SERP naturally while looking for targetHost (handles both direct href and mobile /url?q= wrappers)
      for (let scanStep = 0; scanStep < 4; scanStep++) {
        const match = await session.evaluateIsolated((host) => {
          const anchors = Array.from(document.querySelectorAll('#search a[href], #rso a[href], main a[href], div.g a[href], a[href]'));
          for (const a of anchors) {
            const rawHref = a.href || '';
            if (!rawHref.startsWith('http')) continue;
            let resolvedHref = rawHref;
            try {
              const u = new URL(rawHref);
              if (u.hostname.includes('google.')) {
                const q = u.searchParams.get('q') || u.searchParams.get('url');
                if (q && q.startsWith('http')) resolvedHref = q;
                else continue;
              }
            } catch {
              continue;
            }
            if (resolvedHref.toLowerCase().includes(host)) {
              a.scrollIntoView({ behavior: 'instant', block: 'center' });
              const r = a.getBoundingClientRect();
              if (r.width > 15 && r.height > 10 && r.top >= 0 && r.top < window.innerHeight) {
                return { href: resolvedHref, x: r.left + Math.min(80, r.width / 2), y: r.top + r.height / 2 };
              }
            }
          }
          return null;
        }, targetHost);

        if (match) {
          this.log('success', workerId, `Hedef site Google ${pageNum}. sayfada bulundu -> Organik tıklama yapılıyor (${match.href.slice(0, 65)})`);
          await sleep(randInt(450, 950));
          await session.humanMoveAndClick(match.x, match.y);
          await sleep(randInt(2500, 3800));
          const curHost = await session.evaluateIsolated(() => location.hostname).catch(() => '');
          if (String(curHost).toLowerCase().includes('google.')) {
            await session.goto(match.href, { referrer: googleUrl + '/' });
          }
          this.store.state.stats.serpClicks++;
          return;
        }

        await session.humanReadingScroll(1400, shouldAbort);
      }

      // Click Next SERP page ("Sonraki" / #pnnext / More results)
      if (pageNum < maxPages) {
        const nextBtn = await session.evaluateIsolated(() => {
          const el =
            document.querySelector('#pnnext') ||
            Array.from(document.querySelectorAll('a[aria-label*="Next"], a[aria-label*="Sonraki"], a span')).find((s) =>
              /^(Sonraki|Next|Daha fazla sonuç|More results)$/i.test((s.textContent || '').trim())
            );
          if (!el) return null;
          el.scrollIntoView({ behavior: 'instant', block: 'center' });
          const r = el.getBoundingClientRect();
          return r.width > 10 ? { x: r.left + r.width / 2, y: r.top + r.height / 2 } : null;
        });

        if (!nextBtn) break;
        await session.humanMoveAndClick(nextBtn.x, nextBtn.y);
        await sleep(randInt(2200, 3400));
      }
    }

    // Target wasn't in top maxPages -> Navigate with Google referrer fallback so demo visit still completes
    this.log('warn', workerId, `"${searchQuery}" için ilk ${maxPages} sayfada ${targetHost} görülmedi -> Google yönlendirmesiyle hedefe geçiliyor.`);
    await session.goto(fallbackUrl, { referrer: googleUrl + '/' });
  }

  async _acceptConsentIfPresent(session) {
    try {
      const btn = await session.evaluateIsolated(() => {
        const candidates = Array.from(document.querySelectorAll('button, div[role="button"]'));
        const match = candidates.find((b) =>
          /^(Tümünü kabul et|Kabul ediyorum|Accept all|I agree|Tümünü reddet|Reject all)$/i.test((b.textContent || '').trim())
        );
        if (!match) return null;
        const r = match.getBoundingClientRect();
        return r.width > 20 ? { x: r.left + r.width / 2, y: r.top + r.height / 2 } : null;
      });
      if (btn) {
        await session.humanMoveAndClick(btn.x, btn.y);
        await sleep(1000);
      }
    } catch {}
  }

  async _findVisibleInternalLink(session, targetHost) {
    try {
      return await session.evaluateIsolated((host) => {
        const curUrl = location.href.split('#')[0];
        const links = Array.from(document.querySelectorAll('a[href]')).filter((a) => {
          const href = (a.href || '').split('#')[0];
          if (!href || href === curUrl) return false;
          if (/\.(pdf|zip|rar|exe|jpg|jpeg|png|webp|mp4|svg)(\?|$)/i.test(href)) return false;
          if (/logout|cikis|signout|wp-login|javascript:|mailto:|tel:|whatsapp/i.test(href)) return false;
          const r0 = a.getBoundingClientRect();
          if (r0.width < 12 || r0.height < 10) return false;
          const st = window.getComputedStyle(a);
          if (st.display === 'none' || st.visibility === 'hidden' || Number(st.opacity) === 0) return false;
          try {
            const u = new URL(href);
            return u.hostname.replace(/^www\./i, '').toLowerCase().endsWith(host);
          } catch {
            return false;
          }
        });
        if (!links.length) return null;
        const pick = links[Math.floor(Math.random() * Math.min(links.length, 24))];
        pick.scrollIntoView({ behavior: 'instant', block: 'center' });
        const r = pick.getBoundingClientRect();
        return {
          href: pick.href,
          x: Math.max(10, Math.min(window.innerWidth - 10, r.left + Math.min(60, r.width / 2))),
          y: Math.max(10, Math.min(window.innerHeight - 10, r.top + r.height / 2)),
        };
      }, targetHost);
    } catch {
      return null;
    }
  }
}
