import fs from 'node:fs';
import os from 'node:os';
import net from 'node:net';
import http from 'node:http';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawn } from 'node:child_process';
import { EventEmitter } from 'node:events';
import { buildStealthInitScript } from './fingerprints.mjs';

/**
 * Pure Node.js RFC-6455 WebSocket Client fallback so the software runs with ZERO npm packages
 * even on older Node.js 18 / 20 LTS installations where globalThis.WebSocket may be disabled.
 */
class MinimalWsClient extends EventEmitter {
  constructor(wsUrl) {
    super();
    const u = new URL(wsUrl);
    const key = crypto.randomBytes(16).toString('base64');
    this.socket = null;
    this.closed = false;
    this._buf = Buffer.alloc(0);

    const req = http.request({
      hostname: u.hostname,
      port: Number(u.port) || 80,
      path: u.pathname + u.search,
      method: 'GET',
      headers: {
        Connection: 'Upgrade',
        Upgrade: 'websocket',
        'Sec-WebSocket-Key': key,
        'Sec-WebSocket-Version': '13',
      },
    });

    req.on('upgrade', (_res, socket, head) => {
      this.socket = socket;
      socket.setNoDelay(true);
      if (head && head.length) this._onData(head);
      socket.on('data', (chunk) => this._onData(chunk));
      socket.on('close', () => {
        if (!this.closed) {
          this.closed = true;
          this.emit('close');
        }
      });
      socket.on('error', (err) => this.emit('error', err));
      this.emit('open');
    });

    req.on('error', (err) => this.emit('error', err));
    req.end();
  }

  _onData(chunk) {
    this._buf = Buffer.concat([this._buf, chunk]);
    while (this._buf.length >= 2) {
      const first = this._buf[0];
      const second = this._buf[1];
      const opcode = first & 0x0f;
      const masked = (second & 0x80) !== 0;
      let len = second & 0x7f;
      let offset = 2;

      if (len === 126) {
        if (this._buf.length < 4) return;
        len = this._buf.readUInt16BE(2);
        offset = 4;
      } else if (len === 127) {
        if (this._buf.length < 10) return;
        len = Number(this._buf.readBigUInt64BE(2));
        offset = 10;
      }

      const maskLen = masked ? 4 : 0;
      if (this._buf.length < offset + maskLen + len) return;

      let payload = this._buf.subarray(offset + maskLen, offset + maskLen + len);
      if (masked) {
        const mask = this._buf.subarray(offset, offset + 4);
        payload = Buffer.from(payload);
        for (let i = 0; i < payload.length; i++) payload[i] ^= mask[i & 3];
      }
      this._buf = this._buf.subarray(offset + maskLen + len);

      if (opcode === 0x01) {
        this.emit('message', payload.toString('utf8'));
      } else if (opcode === 0x08) {
        this.close();
        return;
      } else if (opcode === 0x09) {
        this._sendFrame(0x0a, payload);
      }
    }
  }

  _sendFrame(opcode, payloadBuf) {
    if (!this.socket || this.closed) return;
    const len = payloadBuf.length;
    let headerLen = 2;
    if (len >= 126 && len < 65536) headerLen = 4;
    else if (len >= 65536) headerLen = 10;

    const mask = crypto.randomBytes(4);
    const frame = Buffer.allocUnsafe(headerLen + 4 + len);
    frame[0] = 0x80 | opcode;
    if (len < 126) {
      frame[1] = 0x80 | len;
    } else if (len < 65536) {
      frame[1] = 0x80 | 126;
      frame.writeUInt16BE(len, 2);
    } else {
      frame[1] = 0x80 | 127;
      frame.writeBigUInt64BE(BigInt(len), 2);
    }
    mask.copy(frame, headerLen);
    for (let i = 0; i < len; i++) {
      frame[headerLen + 4 + i] = payloadBuf[i] ^ mask[i & 3];
    }
    this.socket.write(frame);
  }

  send(str) {
    this._sendFrame(0x01, Buffer.from(str, 'utf8'));
  }

  close() {
    if (this.closed) return;
    this.closed = true;
    try {
      this._sendFrame(0x08, Buffer.alloc(0));
      this.socket?.end();
      this.socket?.destroy();
    } catch {}
    this.emit('close');
  }
}

/**
 * Discovers installed Chrome / Chromium / Brave / Edge executable across Windows, Linux, and macOS.
 */
export function detectBrowserExecutable(customPath = '') {
  if (customPath && fs.existsSync(customPath)) return customPath;

  const candidates = [];
  if (process.platform === 'win32') {
    const pf = process.env.ProgramFiles || 'C:\\Program Files';
    const pfx86 = process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)';
    const local = process.env.LOCALAPPDATA || '';
    candidates.push(
      path.join(pf, 'Google\\Chrome\\Application\\chrome.exe'),
      path.join(pfx86, 'Google\\Chrome\\Application\\chrome.exe'),
      path.join(local, 'Google\\Chrome\\Application\\chrome.exe'),
      path.join(pf, 'BraveSoftware\\Brave-Browser\\Application\\brave.exe'),
      path.join(pf, 'Microsoft\\Edge\\Application\\msedge.exe'),
      path.join(pfx86, 'Microsoft\\Edge\\Application\\msedge.exe')
    );
  } else if (process.platform === 'darwin') {
    candidates.push(
      '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
      '/Applications/Brave Browser.app/Contents/MacOS/Brave Browser',
      '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge'
    );
  } else {
    candidates.push(
      '/usr/bin/google-chrome',
      '/usr/bin/google-chrome-stable',
      '/usr/bin/chromium-browser',
      '/usr/bin/chromium',
      '/snap/bin/chromium',
      '/usr/bin/brave-browser',
      '/usr/bin/microsoft-edge'
    );
  }

  for (const p of candidates) {
    if (p && fs.existsSync(p)) return p;
  }
  return null;
}

async function getFreePort() {
  return new Promise((resolve, reject) => {
    const srv = net.createServer();
    srv.listen(0, '127.0.0.1', () => {
      const port = srv.address().port;
      srv.close(() => resolve(port));
    });
    srv.on('error', reject);
  });
}

function httpGetJson(url, timeoutMs = 2000) {
  return new Promise((resolve, reject) => {
    const req = http.get(url, { timeout: timeoutMs }, (res) => {
      let data = '';
      res.on('data', (c) => (data += c));
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (e) {
          reject(e);
        }
      });
    });
    req.on('timeout', () => {
      req.destroy();
      reject(new Error('timeout'));
    });
    req.on('error', reject);
  });
}

export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
export const randInt = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

// Critical analytics & search URLs that must NEVER be blocked even in Lightweight Mode
const ESSENTIAL_ALLOW_RE =
  /google-analytics\.com|googletagmanager\.com|analytics\.google\.com|\/g\/collect|\/j\/collect|\/collect\?|stats\.g\.doubleclick\.net|(?:^|\/\/|\.)google\.[a-z.]+|gstatic\.com|googleapis\.com|googleusercontent\.com|recaptcha\.net|challenges\.cloudflare\.com|mc\.yandex\.ru|clarity\.ms|plausible\.io/i;

const ANALYTICS_BEACON_RE =
  /google-analytics\.com\/(g\/|j\/)?collect|analytics\.google\.com\/(g\/)?collect|googletagmanager\.com\/(gtag\/js|gtm\.js)|mc\.yandex\.ru\/watch|clarity\.ms\/collect|plausible\.io\/api\/event/i;

const EST_SAVED_BYTES = {
  Image: 48 * 1024,
  Media: 360 * 1024,
  Font: 85 * 1024,
};

/**
 * Direct Stealth CDP Session:
 * - Launches isolated Chrome/Chromium instance without --enable-automation
 * - Never calls Runtime.enable (defeating Runtime.enable console/stack serialization detection)
 * - Evaluates DOM inspection queries solely inside an isolated V8 world via Page.createIsolatedWorld
 * - Blocks heavy images/media/fonts at network layer while preserving 100% of JS & GA4/GSC beacons
 */
export class StealthBrowserSession extends EventEmitter {
  constructor({
    browserPath = '',
    headless = true,
    lightweight = true,
    fingerprint,
    proxy = null,
    initialCookies = [],
  }) {
    super();
    this.browserPath = detectBrowserExecutable(browserPath);
    if (!this.browserPath) {
      throw new Error('Sistemde Chrome / Chromium / Edge tarayıcısı bulunamadı. Ayarlardan tarayıcı yolunu belirtin.');
    }
    // On Linux servers running Xvfb virtual display (DISPLAY=:99), automatically use real headful X11 mode
    // so Google BotGuard never sees headless Chrome telemetry; if no DISPLAY exists on Linux, fall back to headless=new.
    if (process.platform === 'linux') {
      const dispMatch = String(process.env.DISPLAY || '').match(/^:(\d+)/);
      const hasLiveX11Socket = Boolean(dispMatch && fs.existsSync(`/tmp/.X11-unix/X${dispMatch[1]}`));
      this.headless = hasLiveX11Socket ? false : true;
    } else {
      this.headless = Boolean(headless);
    }
    this.lightweight = Boolean(lightweight);
    this.fp = fingerprint;
    this.proxy = proxy;
    this.initialCookies = initialCookies || [];

    this.proc = null;
    this.ws = null;
    this.port = 0;
    this.userDataDir = '';
    this._msgId = 1;
    this._pending = new Map();
    this._mainFrameId = null;
    this._authAttempts = new Map();

    // Per-session telemetry
    this.metrics = {
      blockedRequests: 0,
      savedBytes: 0,
      analyticsBeacons: 0,
      analyticsUrls: [],
      runtimeEnableCalled: false, // remains strictly false!
    };
  }

  async launch() {
    this.port = await getFreePort();
    this.userDataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'st-cdp-prof-'));

    const args = [
      `--remote-debugging-port=${this.port}`,
      '--remote-debugging-address=127.0.0.1',
      `--user-data-dir=${this.userDataDir}`,
      '--no-first-run',
      '--no-default-browser-check',
      '--disable-blink-features=AutomationControlled',
      '--disable-infobars',
      '--disable-popup-blocking',
      '--disable-background-timer-throttling',
      '--disable-backgrounding-occluded-windows',
      '--disable-renderer-backgrounding',
      '--disable-features=IsolateOrigins,site-per-process,Translate',
      '--password-store=basic',
      '--mute-audio',
      '--webrtc-ip-handling-policy=disable_non_proxied_udp',
      '--force-webrtc-ip-handling-policy',
      '--enforce-webrtc-ip-permission-check',
      `--lang=${this.fp.locale || 'tr-TR'}`,
      `--window-size=${this.fp.viewportWidth},${this.fp.viewportHeight}`,
      '--window-position=0,0',
    ];

    if (process.platform === 'linux') {
      args.push(
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--enable-webgl',
        '--ignore-gpu-blocklist',
        '--use-angle=swiftshader-webgl',
        '--enable-unsafe-swiftshader'
      );
    }
    if (this.headless) {
      args.push('--headless=new', '--hide-scrollbars');
    }
    if (this.proxy?.chromeServerArg) {
      args.push(`--proxy-server=${this.proxy.chromeServerArg}`);
    }
    args.push('about:blank');

    this.proc = spawn(this.browserPath, args, {
      stdio: 'ignore',
      windowsHide: this.headless,
    });

    // Wait for /json/list target page WebSocket
    let pageTarget = null;
    const deadline = Date.now() + 12000;
    while (Date.now() < deadline) {
      try {
        const targets = await httpGetJson(`http://127.0.0.1:${this.port}/json/list`, 1200);
        pageTarget = targets.find((t) => t.type === 'page' && t.webSocketDebuggerUrl);
        if (pageTarget) break;
      } catch {}
      await sleep(200);
    }

    if (!pageTarget) {
      await this.close();
      throw new Error('Tarayıcı CDP portu başlatılamadı (zaman aşımı).');
    }

    await this._connectWs(pageTarget.webSocketDebuggerUrl);
    await this._configureStealthAndNetwork();
    return this;
  }

  async _connectWs(wsUrl) {
    this.ws = new MinimalWsClient(wsUrl);
    await new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error('CDP WebSocket zaman aşımı')), 6000);
      this.ws.once('open', () => {
        clearTimeout(timer);
        resolve();
      });
      this.ws.once('error', (err) => {
        clearTimeout(timer);
        reject(err);
      });
    });

    this.ws.on('message', (raw) => {
      let msg;
      try {
        msg = JSON.parse(raw);
      } catch {
        return;
      }
      if (msg.id) {
        const entry = this._pending.get(msg.id);
        if (entry) {
          this._pending.delete(msg.id);
          clearTimeout(entry.timer);
          if (msg.error) entry.reject(new Error(msg.error.message || 'CDP Error'));
          else entry.resolve(msg.result);
        }
        return;
      }
      if (msg.method) {
        this._handleCdpEvent(msg.method, msg.params || {});
      }
    });

    this.ws.on('close', () => {
      for (const [, entry] of this._pending) {
        clearTimeout(entry.timer);
        entry.reject(new Error('CDP bağlantısı kapandı'));
      }
      this._pending.clear();
    });
  }

  send(method, params = {}, timeoutMs = 15000) {
    if (method === 'Runtime.enable') {
      throw new Error('SECURITY GUARD: Runtime.enable is strictly forbidden in Stealth CDP mode!');
    }
    if (!this.ws || this.ws.closed) {
      return Promise.reject(new Error('CDP oturumu kapalı'));
    }
    const id = this._msgId++;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this._pending.delete(id);
        reject(new Error(`CDP zaman aşımı: ${method}`));
      }, timeoutMs);
      this._pending.set(id, { resolve, reject, timer });
      this.ws.send(JSON.stringify({ id, method, params }));
    });
  }

  _sendFireAndForget(method, params = {}) {
    if (!this.ws || this.ws.closed) return;
    const id = this._msgId++;
    this.ws.send(JSON.stringify({ id, method, params }));
  }

  _handleCdpEvent(method, params) {
    if (method === 'Page.frameNavigated' && !params.frame?.parentId) {
      this._mainFrameId = params.frame.id;
    }

    // Track real GA4 / Analytics beacons fired by the real browser JS engine!
    if (method === 'Network.requestWillBeSent') {
      const url = params.request?.url || '';
      if (ANALYTICS_BEACON_RE.test(url)) {
        this.metrics.analyticsBeacons++;
        if (this.metrics.analyticsUrls.length < 10) {
          this.metrics.analyticsUrls.push(url.slice(0, 140));
        }
        this.emit('analytics_beacon', { url });
      }
    }

    // Lightweight Real Browser Resource Blocking & Proxy Auth
    if (method === 'Fetch.requestPaused') {
      const { requestId, resourceType, request } = params;
      const url = request?.url || '';

      if (
        this.lightweight &&
        (resourceType === 'Image' || resourceType === 'Media' || resourceType === 'Font') &&
        !ESSENTIAL_ALLOW_RE.test(url)
      ) {
        this.metrics.blockedRequests++;
        this.metrics.savedBytes += EST_SAVED_BYTES[resourceType] || 40 * 1024;
        this._sendFireAndForget('Fetch.failRequest', {
          requestId,
          errorReason: 'BlockedByClient',
        });
        return;
      }

      this._sendFireAndForget('Fetch.continueRequest', { requestId });
      return;
    }

    if (method === 'Fetch.authRequired') {
      const { requestId } = params;
      const tries = (this._authAttempts.get(requestId) || 0) + 1;
      this._authAttempts.set(requestId, tries);
      if (this.proxy?.username && tries <= 2) {
        this._sendFireAndForget('Fetch.continueWithAuth', {
          requestId,
          authChallengeResponse: {
            response: 'ProvideCredentials',
            username: this.proxy.username,
            password: this.proxy.password || '',
          },
        });
      } else {
        this._sendFireAndForget('Fetch.continueWithAuth', {
          requestId,
          authChallengeResponse: { response: 'CancelAuth' },
        });
      }
    }

    this.emit(method, params);
  }

  async _configureStealthAndNetwork() {
    await this.send('Page.enable');
    await this.send('Network.enable');

    const tree = await this.send('Page.getFrameTree');
    this._mainFrameId = tree?.frameTree?.frame?.id || null;

    // 1. Hardware, Client-Hints, Viewport, Touch, Locale & Timezone emulation
    // Synchronize User-Agent & Client-Hints with the exact installed Chrome binary version (TLS JA4 / Blink parity)
    let effectiveUa = this.fp.userAgent;
    try {
      const verInfo = await this.send('Browser.getVersion');
      const prodMatch = String(verInfo?.product || '').match(/Chrome\/([\d.]+)/);
      if (prodMatch && prodMatch[1]) {
        const realFull = prodMatch[1];
        const realMajor = realFull.split('.')[0];
        if (this.fp.mobile) {
          effectiveUa = effectiveUa.replace(/(?:Chrome|CriOS)\/[\d.]+/, `Chrome/${realFull}`);
        } else {
          effectiveUa = effectiveUa.replace(/Chrome\/[\d.]+/, `Chrome/${realMajor}.0.0.0`);
        }
        this.fp = { ...this.fp, userAgent: effectiveUa, _realFullVer: realFull, _realMajorVer: realMajor };
      }
    } catch {}

    const majorMatch = effectiveUa.match(/(?:Chrome|CriOS)\/(\d+)/);
    const majorVer = this.fp._realMajorVer || (majorMatch ? majorMatch[1] : '131');
    const fullVerMatch = effectiveUa.match(/(?:Chrome|CriOS)\/([\d.]+)/);
    const fullVer = this.fp._realFullVer || (fullVerMatch ? fullVerMatch[1] : '131.0.6778.135');

    const uaMeta = {
      brands: [
        { brand: 'Google Chrome', version: majorVer },
        { brand: 'Chromium', version: majorVer },
        { brand: 'Not_A Brand', version: '24' },
      ],
      fullVersionList: [
        { brand: 'Google Chrome', version: fullVer },
        { brand: 'Chromium', version: fullVer },
        { brand: 'Not_A Brand', version: '24.0.0.0' },
      ],
      platform: this.fp.uaPlatform || (this.fp.mobile ? 'Android' : 'Windows'),
      platformVersion: this.fp.uaPlatformVersion || '14.0.0',
      architecture: this.fp.mobile ? 'arm' : 'x86',
      model: this.fp.uaModel || '',
      mobile: Boolean(this.fp.mobile),
      bitness: '64',
    };

    await this.send('Emulation.setUserAgentOverride', {
      userAgent: effectiveUa,
      acceptLanguage: this.fp.acceptLanguage || 'tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7',
      platform: this.fp.platform,
      userAgentMetadata: this.fp.uaPlatform === 'iOS' ? undefined : uaMeta,
    });

    await this.send('Emulation.setDeviceMetricsOverride', {
      width: this.fp.viewportWidth,
      height: this.fp.viewportHeight,
      deviceScaleFactor: this.fp.deviceScaleFactor || 1,
      mobile: Boolean(this.fp.mobile),
      screenWidth: this.fp.viewportWidth,
      screenHeight: this.fp.viewportHeight,
    });

    if (this.fp.mobile) {
      const safeTouchPoints = Math.max(1, Math.min(16, Number(this.fp.maxTouchPoints) || 5));
      await this.send('Emulation.setTouchEmulationEnabled', {
        enabled: true,
        maxTouchPoints: safeTouchPoints,
      });
    } else {
      await this.send('Emulation.setTouchEmulationEnabled', {
        enabled: false,
      });
    }

    try {
      await this.send('Emulation.setTimezoneOverride', { timezoneId: this.fp.timezone || 'Europe/Istanbul' });
    } catch {}
    try {
      await this.send('Emulation.setLocaleOverride', { locale: this.fp.locale || 'tr-TR' });
    } catch {}

    // 2. Register Main-World Stealth Preload Script (executes before every page script without Runtime.enable!)
    await this.send('Page.addScriptToEvaluateOnNewDocument', {
      source: buildStealthInitScript(this.fp),
    });

    // 3. Inject pre-warmed cookies into browser cookie jar before first request
    if (this.initialCookies.length > 0) {
      await this.setCookies(this.initialCookies);
    }

    // 4. Enable Lightweight Network Interceptor & Proxy Auth handler if needed
    if (this.lightweight || this.proxy?.username) {
      await this.send('Fetch.enable', {
        handleAuthRequests: Boolean(this.proxy?.username),
        patterns: [{ urlPattern: '*', requestStage: 'Request' }],
      });
    }
  }

  /**
   * Navigates to a URL (with optional HTTP Referer) and waits for load / DOM readiness.
   */
  async goto(url, { referrer = '', timeoutMs = 22000 } = {}) {
    const loadPromise = new Promise((resolve) => {
      let settled = false;
      const done = () => {
        if (settled) return;
        settled = true;
        this.off('Page.loadEventFired', done);
        this.off('Page.domContentEventFired', onDom);
        clearTimeout(timer);
        resolve();
      };
      let domTimer = null;
      const onDom = () => {
        // Settle 1.4s after DOMContentLoaded even if a slow 3rd-party resource hangs
        domTimer = setTimeout(done, 1400);
      };
      const timer = setTimeout(() => {
        if (domTimer) clearTimeout(domTimer);
        done();
      }, timeoutMs);

      this.on('Page.loadEventFired', done);
      this.on('Page.domContentEventFired', onDom);
    });

    const navParams = { url };
    if (referrer) {
      navParams.referrer = referrer;
      navParams.referrerPolicy = 'unsafeUrl';
    }
    let navRes;
    try {
      navRes = await this.send('Page.navigate', navParams, timeoutMs);
    } catch {
      delete navParams.referrerPolicy;
      navRes = await this.send('Page.navigate', navParams, timeoutMs);
    }
    if (navRes?.errorText && /ERR_PROXY|ERR_TUNNEL|ERR_NAME_NOT_RESOLVED|ERR_CONNECTION/i.test(navRes.errorText)) {
      throw new Error(`Sayfa yükleme hatası: ${navRes.errorText}`);
    }
    await loadPromise;
    await sleep(randInt(350, 750));
    return navRes;
  }

  /**
   * Evaluates a function or expression inside an Isolated World (Page.createIsolatedWorld)
   * so Runtime.enable is NEVER called!
   */
  async evaluateIsolated(fnOrExpr, arg = undefined) {
    if (!this._mainFrameId) {
      const tree = await this.send('Page.getFrameTree');
      this._mainFrameId = tree.frameTree.frame.id;
    }
    const world = await this.send('Page.createIsolatedWorld', {
      frameId: this._mainFrameId,
      worldName: 'st_dom_world',
      grantUniveralAccess: true,
    });
    const expression =
      typeof fnOrExpr === 'function'
        ? arg !== undefined
          ? `(${fnOrExpr.toString()})(${JSON.stringify(arg)})`
          : `(${fnOrExpr.toString()})()`
        : String(fnOrExpr);

    const res = await this.send('Runtime.evaluate', {
      expression,
      contextId: world.executionContextId,
      returnByValue: true,
      awaitPromise: true,
    });
    if (res?.exceptionDetails) {
      throw new Error(res.exceptionDetails.text || 'Isolated evaluate hatası');
    }
    return res?.result?.value;
  }

  /**
   * Moves mouse along a smooth human-like curved trajectory before clicking.
   */
  async humanMoveAndClick(x, y) {
    const startX = randInt(40, Math.max(80, Math.min(350, this.fp.viewportWidth - 40)));
    const startY = randInt(60, Math.max(120, Math.min(400, this.fp.viewportHeight - 60)));
    const steps = randInt(7, 13);
    const ctrlX = (startX + x) / 2 + randInt(-45, 45);
    const ctrlY = (startY + y) / 2 + randInt(-35, 35);

    for (let i = 1; i <= steps; i++) {
      const t = i / steps;
      const inv = 1 - t;
      const mx = Math.round(inv * inv * startX + 2 * inv * t * ctrlX + t * t * x);
      const my = Math.round(inv * inv * startY + 2 * inv * t * ctrlY + t * t * y);
      await this.send('Input.dispatchMouseEvent', {
        type: 'mouseMoved',
        x: mx,
        y: my,
        button: 'none',
      });
      await sleep(randInt(10, 24));
    }

    await sleep(randInt(35, 95));
    await this.send('Input.dispatchMouseEvent', {
      type: 'mousePressed',
      x: Math.round(x),
      y: Math.round(y),
      button: 'left',
      clickCount: 1,
    });
    await sleep(randInt(45, 110));
    await this.send('Input.dispatchMouseEvent', {
      type: 'mouseReleased',
      x: Math.round(x),
      y: Math.round(y),
      button: 'left',
      clickCount: 1,
    });
  }

  /**
   * Types text character-by-character with genuine hardware keyDown/keyUp events & human cadence.
   */
  async humanType(text, { minDelay = 55, maxDelay = 155 } = {}) {
    for (const ch of String(text)) {
      if (/^[a-zA-Z0-9 ]$/.test(ch)) {
        const isSpace = ch === ' ';
        const upper = ch.toUpperCase();
        const vk = isSpace ? 32 : upper.charCodeAt(0);
        const code = isSpace ? 'Space' : /^[0-9]$/.test(ch) ? `Digit${ch}` : `Key${upper}`;
        await this.send('Input.dispatchKeyEvent', {
          type: 'keyDown',
          key: ch,
          code,
          text: ch,
          unmodifiedText: ch,
          windowsVirtualKeyCode: vk,
          nativeVirtualKeyCode: vk,
        });
        await sleep(randInt(35, 75));
        await this.send('Input.dispatchKeyEvent', {
          type: 'keyUp',
          key: ch,
          code,
          windowsVirtualKeyCode: vk,
          nativeVirtualKeyCode: vk,
        });
      } else {
        await this.send('Input.insertText', { text: ch });
      }
      const pause = ch === ' ' ? randInt(110, 240) : randInt(minDelay, maxDelay);
      await sleep(pause);
    }
  }

  async pressEnter() {
    await this.send('Input.dispatchKeyEvent', {
      type: 'rawKeyDown',
      windowsVirtualKeyCode: 13,
      nativeVirtualKeyCode: 13,
      key: 'Enter',
      code: 'Enter',
      text: '\r',
    });
    await sleep(randInt(35, 75));
    await this.send('Input.dispatchKeyEvent', {
      type: 'keyUp',
      windowsVirtualKeyCode: 13,
      nativeVirtualKeyCode: 13,
      key: 'Enter',
      code: 'Enter',
    });
  }

  /**
   * Performs human reading scroll bursts down (and occasional slight scroll-back) using trusted wheel events.
   */
  async humanReadingScroll(durationMs = 8000, shouldAbort = () => false) {
    const endAt = Date.now() + durationMs;
    const cx = Math.round(this.fp.viewportWidth * 0.5);
    const cy = Math.round(this.fp.viewportHeight * 0.55);

    while (Date.now() < endAt && !shouldAbort()) {
      const goUp = Math.random() < 0.16;
      const totalDelta = goUp ? -randInt(120, 260) : randInt(220, 540);
      const ticks = randInt(4, 8);
      const stepDelta = Math.round(totalDelta / ticks);

      for (let i = 0; i < ticks; i++) {
        await this.send('Input.dispatchMouseEvent', {
          type: 'mouseWheel',
          x: cx + randInt(-20, 20),
          y: cy + randInt(-20, 20),
          deltaX: 0,
          deltaY: stepDelta,
        });
        await sleep(randInt(25, 55));
      }

      // Natural reading pause between scroll gestures
      const remaining = endAt - Date.now();
      if (remaining <= 0) break;
      await sleep(Math.min(remaining, randInt(900, 2400)));
    }
  }

  async getCookies() {
    const res = await this.send('Network.getAllCookies');
    return res?.cookies || [];
  }

  async setCookies(cookies = []) {
    if (!cookies.length) return;
    const formatted = cookies
      .filter((c) => c && c.name && c.domain)
      .map((c) => ({
        name: String(c.name),
        value: String(c.value ?? ''),
        domain: String(c.domain),
        path: String(c.path || '/'),
        expires: Number(c.expires) > 0 ? Number(c.expires) : undefined,
        httpOnly: Boolean(c.httpOnly),
        secure: Boolean(c.secure),
        sameSite: ['Strict', 'Lax', 'None'].includes(c.sameSite) ? c.sameSite : undefined,
      }));
    if (formatted.length) {
      await this.send('Network.setCookies', { cookies: formatted });
    }
  }

  async close() {
    try {
      if (this.ws && !this.ws.closed) {
        try {
          this._sendFireAndForget('Browser.close');
        } catch {}
        await sleep(120);
        this.ws.close();
      }
    } catch {}
    try {
      if (this.proc && !this.proc.killed) {
        this.proc.kill();
      }
    } catch {}
    await sleep(250);
    if (this.userDataDir) {
      try {
        fs.rmSync(this.userDataDir, { recursive: true, force: true });
      } catch {}
    }
  }
}
