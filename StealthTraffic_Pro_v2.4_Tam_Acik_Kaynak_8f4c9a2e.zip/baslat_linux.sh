#!/usr/bin/env bash
echo "StealthTraffic Pro v2.4 Baslatiliyor - http://127.0.0.1:3850"
node server.mjs
