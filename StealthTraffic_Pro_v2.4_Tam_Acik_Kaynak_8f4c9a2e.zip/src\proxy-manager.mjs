import net from 'node:net';
import http from 'node:http';
import https from 'node:https';
import crypto from 'node:crypto';

/**
 * Parses common proxy formats:
 * - http://user:pass@host:port
 * - socks5://user:pass@host:port
 * - host:port:user:pass
 * - user:pass@host:port
 * - host:port
 */
export function parseProxyLine(rawLine) {
  const line = String(rawLine || '').trim();
  if (!line || line.startsWith('#')) return null;

  let protocol = 'http';
  let rest = line;

  const protoMatch = rest.match(/^(https?|socks5|socks4):\/\//i);
  if (protoMatch) {
    protocol = protoMatch[1].toLowerCase();
    rest = rest.slice(protoMatch[0].length);
  }

  let host = '';
  let port = 0;
  let username = '';
  let password = '';

  if (rest.includes('@')) {
    const atIdx = rest.lastIndexOf('@');
    const authPart = rest.slice(0, atIdx);
    const hostPart = rest.slice(atIdx + 1);
    const colonAuth = authPart.indexOf(':');
    if (colonAuth >= 0) {
      username = decodeURIComponent(authPart.slice(0, colonAuth));
      password = decodeURIComponent(authPart.slice(colonAuth + 1));
    } else {
      username = decodeURIComponent(authPart);
    }
    const [h, p] = hostPart.split(':');
    host = h;
    port = Number(p);
  } else {
    const parts = rest.split(':');
    if (parts.length === 2) {
      host = parts[0];
      port = Number(parts[1]);
    } else if (parts.length >= 4) {
      host = parts[0];
      port = Number(parts[1]);
      username = parts[2];
      password = parts.slice(3).join(':');
    }
  }

  if (!host || !Number.isFinite(port) || port <= 0 || port > 65535) {
    return null;
  }

  return {
    id: 'PX-' + crypto.createHash('md5').update(`${protocol}://${username}@${host}:${port}`).digest('hex').slice(0, 8).toUpperCase(),
    protocol,
    host,
    port,
    username,
    password,
    raw: line,
    chromeServerArg: `${protocol}://${host}:${port}`,
    label: username ? `${protocol}://${username}:***@${host}:${port}` : `${protocol}://${host}:${port}`,
    status: 'untested',
    latencyMs: null,
    exitIp: null,
    failCount: 0,
    successCount: 0,
    lastUsedAt: null,
  };
}

/**
 * Checks TCP reachability (and HTTP proxy exit IP if HTTP/HTTPS proxy) with a clean timeout.
 */
export async function testProxyConnectivity(proxy, timeoutMs = 6000) {
  const started = Date.now();
  const tcpOk = await new Promise((resolve) => {
    const socket = net.createConnection({ host: proxy.host, port: proxy.port });
    let done = false;
    const finish = (ok) => {
      if (done) return;
      done = true;
      socket.destroy();
      resolve(ok);
    };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
  });

  if (!tcpOk) {
    return { ok: false, latencyMs: Date.now() - started, exitIp: null, error: 'TCP bağlantı zaman aşımı / reddedildi' };
  }

  // If HTTP proxy, perform quick HTTP proxy request to api.ipify.org to resolve actual exit IP
  if (proxy.protocol === 'http' || proxy.protocol === 'https') {
    const ipResult = await new Promise((resolve) => {
      const headers = { Host: 'api.ipify.org', 'User-Agent': 'Mozilla/5.0' };
      if (proxy.username) {
        const token = Buffer.from(`${proxy.username}:${proxy.password || ''}`).toString('base64');
        headers['Proxy-Authorization'] = `Basic ${token}`;
      }
      const req = http.request(
        {
          host: proxy.host,
          port: proxy.port,
          method: 'GET',
          path: 'http://api.ipify.org?format=json',
          headers,
          timeout: timeoutMs,
        },
        (res) => {
          let body = '';
          res.on('data', (chunk) => (body += chunk));
          res.on('end', () => {
            try {
              const parsed = JSON.parse(body);
              resolve({ ok: true, exitIp: parsed.ip || null });
            } catch {
              resolve({ ok: res.statusCode < 500, exitIp: null });
            }
          });
        }
      );
      req.on('timeout', () => {
        req.destroy();
        resolve({ ok: true, exitIp: null });
      });
      req.on('error', () => resolve({ ok: true, exitIp: null }));
      req.end();
    });

    return {
      ok: ipResult.ok,
      latencyMs: Date.now() - started,
      exitIp: ipResult.exitIp,
      error: null,
    };
  }

  return {
    ok: true,
    latencyMs: Date.now() - started,
    exitIp: null,
    error: null,
  };
}

const SESSION_CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

function randomAlnum(len = 8) {
  let out = '';
  for (let i = 0; i < len; i++) {
    out += SESSION_CHARS[crypto.randomInt(0, SESSION_CHARS.length)];
  }
  return out;
}

function rotateStickyToken(str) {
  if (!str) return { value: str, sessionTag: null };
  let sessionTag = null;
  // IPRoyal sticky format: _country-tr_session-vSDda39L_lifetime-5m
  let next = String(str).replace(/(_session-)([A-Za-z0-9]{4,24})/, (_m, prefix, oldTok) => {
    sessionTag = randomAlnum(Math.max(8, Math.min(12, oldTok.length || 8)));
    return `${prefix}${sessionTag}`;
  });
  if (sessionTag) return { value: next, sessionTag };

  // BrightData / Oxylabs / Smartproxy / SOAX / PacketStream sticky formats: -session-xxx, _sessid-xxx, session-xxx
  next = next.replace(/((?:^|[-_])(?:session|sessid)[-_])([A-Za-z0-9]{4,24})/i, (_m, prefix, oldTok) => {
    sessionTag = randomAlnum(Math.max(8, Math.min(12, oldTok.length || 8)));
    return `${prefix}${sessionTag}`;
  });
  return { value: next, sessionTag };
}

/**
 * Clones a proxy entry for a single browser visitor session, automatically generating
 * a fresh sticky-session token (IPRoyal / BrightData / Smartproxy / Oxylabs) so even
 * a single pasted sticky proxy line rotates a unique residential IP per visitor while
 * staying sticky throughout that visitor's SERP + target subpage journey.
 */
export function materializeSessionProxy(proxy) {
  if (!proxy) return null;
  const uRot = rotateStickyToken(proxy.username || '');
  const pRot = rotateStickyToken(proxy.password || '');
  const sessionTag = pRot.sessionTag || uRot.sessionTag;
  if (!sessionTag) {
    return { ...proxy, baseProxy: proxy };
  }
  return {
    ...proxy,
    baseProxy: proxy,
    username: uRot.value,
    password: pRot.value,
    sessionTag,
    label: `${proxy.label} [IP-Oturum: ${sessionTag}]`,
  };
}

/**
 * Triggers a Mobile Proxy Rotating IP Reset webhook URL (HTTP/HTTPS GET).
 */
export async function triggerMobileIpRotation(rotationUrl, timeoutMs = 10000) {
  if (!rotationUrl || !/^https?:\/\//i.test(rotationUrl)) {
    return { ok: false, error: 'Geçerli bir HTTP/HTTPS IP yenileme URL adresi girilmedi.' };
  }

  return new Promise((resolve) => {
    const client = rotationUrl.startsWith('https') ? https : http;
    const req = client.get(rotationUrl, { timeout: timeoutMs }, (res) => {
      let body = '';
      res.on('data', (d) => (body += d));
      res.on('end', () => {
        resolve({
          ok: res.statusCode >= 200 && res.statusCode < 400,
          statusCode: res.statusCode,
          responsePreview: body.trim().slice(0, 180),
        });
      });
    });
    req.on('timeout', () => {
      req.destroy();
      resolve({ ok: false, error: 'IP yenileme API zaman aşımına uğradı.' });
    });
    req.on('error', (err) => {
      resolve({ ok: false, error: err.message });
    });
  });
}
