let appState = null;
let settingsLoadedOnce = false;

const $ = (id) => document.getElementById(id);

function escapeHtml(str) {
  return String(str ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function toast(msg, isError = false) {
  const wrap = $('toastContainer');
  const el = document.createElement('div');
  el.className = 'toast' + (isError ? ' err' : '');
  el.textContent = msg;
  wrap.appendChild(el);
  setTimeout(() => el.remove(), 3800);
}

async function api(url, method = 'GET', body = null) {
  const opts = { method, headers: {} };
  if (body !== null) {
    opts.headers['Content-Type'] = 'application/json';
    opts.body = JSON.stringify(body);
  }
  const res = await fetch(url, opts);
  const data = await res.json();
  if (!res.ok || data.ok === false) {
    throw new Error(data.error || 'İşlem başarısız');
  }
  return data;
}

const MODE_LABELS = {
  serp: { text: 'Google SERP Tıklama', cls: 'badge-green' },
  branded: { text: 'Markalı Autocomplete', cls: 'badge-blue' },
  referrer: { text: 'Sosyal / Referrer', cls: 'badge-amber' },
  direct: { text: 'Direkt & GA4 Anlık', cls: 'badge-slate' },
};

const STATUS_LABELS = {
  running: { text: 'Çalışıyor', cls: 'badge-green' },
  paused: { text: 'Duraklatıldı', cls: 'badge-amber' },
  completed: { text: 'Tamamlandı', cls: 'badge-blue' },
};

function renderSnapshot(snap) {
  appState = snap;
  const st = snap.stats || {};
  const ck = snap.cookieSummary || {};
  const rt = snap.runtime || {};
  const proxies = snap.proxies || [];

  // Browser status pill
  const bText = $('browserStatusText');
  const bDot = $('browserStatusPill').querySelector('.dot');
  if (snap.detectedBrowser) {
    const shortName = snap.detectedBrowser.split(/[\\/]/).pop();
    bText.textContent = `Stealth Motor Hazır (${shortName})`;
    bDot.className = 'dot dot-ok';
  } else {
    bText.textContent = 'Tarayıcı Bulunamadı (Ayarlardan Seçin)';
    bDot.className = 'dot dot-err';
  }

  // KPIs
  $('kpiSuccess').textContent = st.successfulSessions || 0;
  $('kpiSubpages').textContent = st.subpagesVisited || 0;
  const avgDwell = st.successfulSessions > 0 ? Math.round((st.totalDwellSeconds || 0) / st.successfulSessions) : 0;
  $('kpiAvgDwell').textContent = avgDwell;
  $('kpiGaHits').textContent = st.analyticsBeaconsVerified || 0;
  $('kpiActiveWorkers').textContent = (rt.activeWorkers || []).length;
  $('kpiSerpClicks').textContent = st.serpClicks || 0;
  $('kpiBranded').textContent = st.brandedSearches || 0;

  $('kpiCookiePool').textContent = ck.totalProfiles || 0;
  $('kpiCookieGa').textContent = ck.gaReadyCount || 0;
  $('kpiCookieGoogle').textContent = ck.googleReadyCount || 0;
  $('kpiCookieScore').textContent = ck.avgScore || 0;

  const savedMb = ((st.savedBandwidthBytes || 0) / (1024 * 1024)).toFixed(1);
  $('kpiSavedMb').textContent = `${savedMb} MB`;
  $('kpiBlockedReq').textContent = st.blockedHeavyRequests || 0;

  const activePx = proxies.filter((p) => p.status === 'active').length;
  $('kpiProxies').textContent = `${activePx} / ${proxies.length}`;

  // Active Workers strip
  const workers = rt.activeWorkers || [];
  $('activeWorkerCountBadge').textContent = workers.length;
  const wList = $('activeWorkersList');
  if (!workers.length) {
    wList.innerHTML = `<div class="empty-hint">Şu anda aktif çalışan oturum yok. Aşağıdan bir kampanya başlatabilir veya sağ üstten <strong>⚡ Hızlı Canlı Demo</strong> gönderebilirsiniz.</div>`;
  } else {
    wList.innerHTML = workers
      .map(
        (w) => `
      <div class="worker-pill-card">
        <div class="worker-top">
          <span>${escapeHtml(w.id)}</span>
          <span>${escapeHtml(w.type.toUpperCase())}</span>
        </div>
        <div class="worker-step">${escapeHtml(w.step)}</div>
        <div class="worker-meta">${escapeHtml(w.device)} &bull; ${escapeHtml(w.proxy)}</div>
      </div>`
      )
      .join('');
  }

  // Campaigns Table
  const cBody = $('campaignsTableBody');
  const campaigns = snap.campaigns || [];
  if (!campaigns.length) {
    cBody.innerHTML = `<tr><td colspan="7" class="empty-hint">Henüz kampanya oluşturulmadı.</td></tr>`;
  } else {
    cBody.innerHTML = campaigns
      .map((c) => {
        const mInfo = MODE_LABELS[c.mode] || MODE_LABELS.direct;
        const isRunning = (rt.runningCampaignIds || []).includes(c.id);
        const sInfo = isRunning ? STATUS_LABELS.running : STATUS_LABELS[c.status] || STATUS_LABELS.paused;
        const pct = c.targetVisits > 0 ? Math.min(100, Math.round(((c.completedVisits || 0) / c.targetVisits) * 100)) : 0;
        const kwPreview = (c.keywords || []).slice(0, 2).join(', ');
        return `
        <tr>
          <td>
            <strong>${escapeHtml(c.name)}</strong><br/>
            <span style="color:var(--text-muted);font-size:11.5px;">${escapeHtml(c.targetDomain)} ${kwPreview ? '&bull; ' + escapeHtml(kwPreview) : ''}</span>
          </td>
          <td><span class="badge ${mInfo.cls}">${mInfo.text}</span></td>
          <td>
            <div><strong>${c.completedVisits || 0}</strong> / ${c.targetVisits || '∞'} (${pct}%)</div>
            <div class="prog-bar"><div class="prog-fill" style="width:${pct}%"></div></div>
          </td>
          <td><span class="badge badge-green">${c.verifiedGaHits || 0} GA4 ✓</span></td>
          <td style="font-size:11.5px;color:var(--text-muted);">
            %${c.mobileRatio ?? 70} Mobil &bull; ${c.concurrency} Thread<br/>
            ${c.dwellMinSec}-${c.dwellMaxSec}sn &bull; ${c.subpagesMin}-${c.subpagesMax} Alt Sayfa
          </td>
          <td><span class="badge ${sInfo.cls}">${sInfo.text}</span></td>
          <td>
            <div class="btn-row">
              ${
                isRunning
                  ? `<button class="btn btn-secondary btn-xs" onclick="campaignAction('${escapeHtml(c.id)}','pause')">Duraklat</button>`
                  : `<button class="btn btn-primary btn-xs" onclick="campaignAction('${escapeHtml(c.id)}','start')">Başlat</button>`
              }
              <button class="btn btn-secondary btn-xs" onclick="editCampaign('${escapeHtml(c.id)}')">Düzenle</button>
              <button class="btn btn-ghost btn-xs" onclick="campaignAction('${escapeHtml(c.id)}','reset')">Sıfırla</button>
              <button class="btn btn-danger btn-xs" onclick="campaignAction('${escapeHtml(c.id)}','delete')">Sil</button>
            </div>
          </td>
        </tr>`;
      })
      .join('');
  }

  // Cookie Warmup Job state
  const cj = rt.cookieJob || {};
  if (cj.running) {
    $('btnStartCookieWarmup').classList.add('hidden');
    $('btnStopCookieWarmup').classList.remove('hidden');
    $('cookieJobProgressBox').classList.remove('hidden');
    $('cookieJobProgressText').textContent = `Otomatik çerez profilleri üretiliyor ve yaşlandırılıyor: ${cj.completed} / ${cj.total}`;
  } else {
    $('btnStartCookieWarmup').classList.remove('hidden');
    $('btnStopCookieWarmup').classList.add('hidden');
    $('cookieJobProgressBox').classList.add('hidden');
  }

  // Cookie Pool Table
  const ckBody = $('cookiesTableBody');
  const profiles = ck.profiles || [];
  if (!profiles.length) {
    ckBody.innerHTML = `<tr><td colspan="7" class="empty-hint">Çerez havuzu henüz boş. Yukarıdan "Çerez Üretimini Başlat" butonuna tıklayarak otomatik organik çerez üretebilirsiniz.</td></tr>`;
  } else {
    ckBody.innerHTML = profiles
      .slice(0, 120)
      .map(
        (p) => `
      <tr>
        <td><strong>${escapeHtml(p.id)}</strong></td>
        <td>
          ${escapeHtml(p.label)}<br/>
          <span class="badge ${p.deviceType === 'mobile' ? 'badge-blue' : 'badge-slate'}">${p.deviceType === 'mobile' ? 'Mobil' : 'Masaüstü'}</span>
        </td>
        <td><strong>${p.cookieCount}</strong> çerez &bull; ${p.domainCount} domain</td>
        <td>
          ${p.hasGaCookie ? '<span class="badge badge-green">_ga ✓</span> ' : ''}
          ${p.hasGoogleCookies ? '<span class="badge badge-blue">Google NID/AEC ✓</span>' : ''}
          ${!p.hasGaCookie && !p.hasGoogleCookies ? '<span class="badge badge-slate">Standart</span>' : ''}
        </td>
        <td><strong>${p.warmScore} / 100</strong> (${p.warmupVisits} tur)</td>
        <td>${p.useCount || 0} kez</td>
        <td>
          <div class="btn-row">
            <a class="btn btn-secondary btn-xs" href="/api/cookies/export?format=netscape&id=${encodeURIComponent(p.id)}" target="_blank">.txt</a>
            <button class="btn btn-danger btn-xs" onclick="deleteCookieProfile('${escapeHtml(p.id)}')">Sil</button>
          </div>
        </td>
      </tr>`
      )
      .join('');
  }

  // Proxies Table
  const pxBody = $('proxiesTableBody');
  if (!proxies.length) {
    pxBody.innerHTML = `<tr><td colspan="7" class="empty-hint">Henüz proxy eklenmedi (Direkt bağlantı ile de çalışabilir; Google SERP için Mobil/Residential proxy önerilir).</td></tr>`;
  } else {
    pxBody.innerHTML = proxies
      .map((p) => {
        const stBadge =
          p.status === 'active'
            ? '<span class="badge badge-green">Aktif</span>'
            : p.status === 'dead'
            ? '<span class="badge badge-red">Yanıt Yok</span>'
            : '<span class="badge badge-slate">Test Edilmedi</span>';
        return `
        <tr>
          <td><strong>${escapeHtml(p.id)}</strong></td>
          <td><code>${escapeHtml(p.label)}</code></td>
          <td>${stBadge}</td>
          <td>${p.latencyMs ? p.latencyMs + ' ms' : '-'}</td>
          <td>${escapeHtml(p.exitIp || '-')}</td>
          <td>${p.successCount || 0}</td>
          <td><button class="btn btn-danger btn-xs" onclick="deleteProxy('${escapeHtml(p.id)}')">Sil</button></td>
        </tr>`;
      })
      .join('');
  }

  // Populate settings inputs once on initial load so we don't overwrite while user types
  if (!settingsLoadedOnce && snap.settings) {
    settingsLoadedOnce = true;
    populateSettingsForm(snap.settings);
  }
}

function populateSettingsForm(s) {
  $('setBrowserPath').value = s.browserPath || '';
  $('setGoogleDomain').value = s.googleDomain || 'https://www.google.com.tr';
  $('setMaxConcurrency').value = s.maxGlobalConcurrency || 4;
  $('setLocale').value = s.defaultLocale || 'tr-TR';
  $('setTimezone').value = s.defaultTimezone || 'Europe/Istanbul';
  $('setLightweight').checked = s.lightweightMode !== false;
  $('setHeadless').checked = s.headlessMode !== false;
  $('setHourlyEnabled').checked = Boolean(s.hourlyCurveEnabled);
  $('setSeedSites').value = (s.cookieSeedSites || []).join('\n');
  $('rotApiUrl').value = s.mobileRotationUrl || '';
  $('rotEveryN').value = s.rotateEverySessions || 5;

  const curve = Array.isArray(s.hourlyCurve) && s.hourlyCurve.length === 24 ? s.hourlyCurve : new Array(24).fill(100);
  const grid = $('hourlyBarsContainer');
  grid.innerHTML = curve
    .map(
      (val, hr) => `
    <div class="hour-cell">
      <span>${String(hr).padStart(2, '0')}:00 (%)</span>
      <input type="number" class="hour-input" data-hour="${hr}" min="0" max="100" value="${val}" />
    </div>`
    )
    .join('');
}

function appendLog(entry) {
  const stream = $('liveLogStream');
  const div = document.createElement('div');
  div.className = 'log-line';
  const cls =
    entry.level === 'success'
      ? 'log-success'
      : entry.level === 'warn'
      ? 'log-warn'
      : entry.level === 'error'
      ? 'log-error'
      : 'log-info';
  div.innerHTML = `<span class="log-time">[${escapeHtml(entry.time)}]</span><span class="log-worker">[${escapeHtml(entry.worker)}]</span><span class="${cls}">${escapeHtml(entry.message)}</span>`;
  stream.appendChild(div);
  while (stream.children.length > 220) {
    stream.removeChild(stream.firstChild);
  }
  stream.scrollTop = stream.scrollHeight;
}

// === GLOBAL WINDOW HANDLERS FOR TABLE BUTTONS ===
window.campaignAction = async (id, action) => {
  try {
    if (action === 'delete' && !confirm('Bu kampanyayı silmek istediğinize emin misiniz?')) return;
    await api(`/api/campaigns/${encodeURIComponent(id)}/${action}`, 'POST');
    toast(
      action === 'start'
        ? 'Kampanya başlatıldı.'
        : action === 'pause'
        ? 'Kampanya duraklatıldı.'
        : action === 'reset'
        ? 'Kampanya sayaçları sıfırlandı.'
        : 'Kampanya silindi.'
    );
  } catch (e) {
    toast(e.message, true);
  }
};

window.editCampaign = (id) => {
  const c = (appState?.campaigns || []).find((x) => x.id === id);
  if (!c) return;
  $('campModalTitle').textContent = `Kampanyayı Düzenle (${c.id})`;
  $('campId').value = c.id;
  $('campName').value = c.name || '';
  $('campMode').value = c.mode || 'serp';
  $('campDomain').value = c.targetDomain || '';
  $('campBrand').value = c.brandName || '';
  $('campUrls').value = (c.targetUrls || []).join('\n');
  $('campKeywords').value = (c.keywords || []).join('\n');
  $('campReferrers').value = (c.referrers || []).join('\n');
  $('campTargetVisits').value = c.targetVisits ?? 100;
  $('campConcurrency').value = c.concurrency ?? 2;
  $('campMobileRatio').value = c.mobileRatio ?? 70;
  $('campMaxSerp').value = c.maxSerpPages ?? 3;
  $('campDwellMin').value = c.dwellMinSec ?? 30;
  $('campDwellMax').value = c.dwellMaxSec ?? 70;
  $('campSubMin').value = c.subpagesMin ?? 1;
  $('campSubMax').value = c.subpagesMax ?? 3;
  $('campUseCookies').checked = c.useCookiePool !== false;
  $('campAutoWarm').checked = c.autoWarmIfEmpty !== false;
  $('campLightweight').checked = c.lightweightMode !== false;
  $('campHeadless').checked = c.headlessMode !== false;
  $('campUseProxies').checked = Boolean(c.useProxies);
  $('modalCampaign').classList.remove('hidden');
};

window.deleteCookieProfile = async (id) => {
  try {
    await api('/api/cookies/clear', 'POST', { id });
    toast(`Çerez profili (${id}) silindi.`);
  } catch (e) {
    toast(e.message, true);
  }
};

window.deleteProxy = async (id) => {
  try {
    await api('/api/proxies/clear', 'POST', { id });
    toast('Proxy silindi.');
  } catch (e) {
    toast(e.message, true);
  }
};

// === EVENT LISTENERS ===
document.querySelectorAll('.tab-btn').forEach((btn) => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab-btn').forEach((b) => b.classList.remove('active'));
    document.querySelectorAll('.tab-pane').forEach((p) => p.classList.remove('active'));
    btn.classList.add('active');
    $(btn.dataset.tab).classList.add('active');
  });
});

document.querySelectorAll('[data-close]').forEach((btn) => {
  btn.addEventListener('click', () => $(btn.dataset.close).classList.add('hidden'));
});

$('btnOpenQuickDemo').addEventListener('click', () => {
  $('modalQuickDemo').classList.remove('hidden');
});

$('btnSubmitQuickDemo').addEventListener('click', async () => {
  try {
    const targetUrl = $('demoUrl').value.trim();
    if (!targetUrl) return toast('Lütfen hedef site URL adresini girin.', true);
    await api('/api/demo/start', 'POST', {
      targetUrl,
      mode: $('demoMode').value,
      keyword: $('demoKeyword').value.trim(),
      visits: Number($('demoVisits').value) || 3,
      concurrency: Number($('demoConcurrency').value) || 2,
      dwellSec: Number($('demoDwell').value) || 35,
      subpages: Number($('demoSubpages').value) || 2,
      lightweight: $('demoLightweight').checked,
      headless: !$('demoVisibleWindow').checked,
      useCookiePool: $('demoUseCookies').checked,
      useProxies: $('demoUseProxies').checked,
    });
    $('modalQuickDemo').classList.add('hidden');
    toast('Canlı demo trafiği başlatıldı! Sağdaki günlükten anlık takip edebilirsiniz.');
  } catch (e) {
    toast(e.message, true);
  }
});

$('btnNewCampaign').addEventListener('click', () => {
  $('campModalTitle').textContent = 'Yeni Trafik Kampanyası Oluştur';
  $('campId').value = '';
  $('campName').value = '';
  $('campDomain').value = '';
  $('campBrand').value = '';
  $('campUrls').value = '';
  $('campKeywords').value = '';
  $('modalCampaign').classList.remove('hidden');
});

$('btnBulkCampaign')?.addEventListener('click', () => {
  $('modalBulkCampaign').classList.remove('hidden');
});

$('btnSubmitBulkCampaign')?.addEventListener('click', async () => {
  try {
    const lines = $('bulkDomainsInput').value.trim();
    if (!lines) return toast('Lütfen satır satır domain | kelime1, kelime2 listesini girin.', true);
    const r = await api('/api/campaigns/bulk', 'POST', {
      lines,
      mode: $('bulkMode').value,
      targetVisits: Number($('bulkVisits').value) || 100,
      concurrency: Number($('bulkConcurrency').value) || 2,
      dwellMinSec: Number($('bulkDwellMin').value) || 35,
      dwellMaxSec: Number($('bulkDwellMax').value) || 75,
      useProxies: $('bulkUseProxies').checked,
      autoStart: $('bulkAutoStart').checked,
    });
    $('modalBulkCampaign').classList.add('hidden');
    toast(`${r.count} farklı domain ve özel kelime listesi eklendi!`);
  } catch (e) {
    toast(e.message, true);
  }
});

$('btnSaveCampaign').addEventListener('click', async () => {
  try {
    const domain = $('campDomain').value.trim();
    const urls = $('campUrls').value.trim();
    if (!domain && !urls) return toast('Lütfen hedef domain veya hedef URL girin.', true);
    await api('/api/campaigns', 'POST', {
      id: $('campId').value || undefined,
      name: $('campName').value.trim() || `Kampanya: ${domain || urls.split('\n')[0]}`,
      mode: $('campMode').value,
      targetDomain: domain,
      brandName: $('campBrand').value.trim(),
      targetUrls: urls,
      keywords: $('campKeywords').value,
      referrers: $('campReferrers').value,
      targetVisits: Number($('campTargetVisits').value) || 100,
      concurrency: Number($('campConcurrency').value) || 2,
      mobileRatio: Number($('campMobileRatio').value ?? 70),
      maxSerpPages: Number($('campMaxSerp').value) || 3,
      dwellMinSec: Number($('campDwellMin').value) || 30,
      dwellMaxSec: Number($('campDwellMax').value) || 70,
      subpagesMin: Number($('campSubMin').value ?? 1),
      subpagesMax: Number($('campSubMax').value ?? 3),
      useCookiePool: $('campUseCookies').checked,
      autoWarmIfEmpty: $('campAutoWarm').checked,
      lightweightMode: $('campLightweight').checked,
      headlessMode: $('campHeadless').checked,
      useProxies: $('campUseProxies').checked,
    });
    $('modalCampaign').classList.add('hidden');
    toast('Kampanya kaydedildi.');
  } catch (e) {
    toast(e.message, true);
  }
});

// Cookie Pool actions
$('btnStartCookieWarmup').addEventListener('click', async () => {
  try {
    await api('/api/cookies/warmup', 'POST', {
      count: Number($('ckCount').value) || 5,
      concurrency: Number($('ckConcurrency').value) || 2,
      deviceType: $('ckDeviceType').value,
      sitesPerProfile: Number($('ckSitesCount').value) || 3,
      useProxies: $('ckUseProxies').checked,
    });
    toast('Otomatik çerez üretim görevi başlatıldı.');
  } catch (e) {
    toast(e.message, true);
  }
});

$('btnStopCookieWarmup').addEventListener('click', async () => {
  await api('/api/cookies/stop', 'POST');
  toast('Durdurma sinyali gönderildi.');
});

$('btnOpenCookieImport').addEventListener('click', () => {
  $('cookieImportTextarea').value = '';
  $('modalCookieImport').classList.remove('hidden');
});

$('btnSubmitCookieImport').addEventListener('click', async () => {
  try {
    const payload = $('cookieImportTextarea').value.trim();
    if (!payload) return toast('Lütfen çerez verisini yapıştırın.', true);
    const r = await api('/api/cookies/import', 'POST', { payload });
    $('modalCookieImport').classList.add('hidden');
    toast(`${r.importedProfiles} profil (${r.totalCookies} çerez) başarıyla içe aktarıldı.`);
  } catch (e) {
    toast(e.message, true);
  }
});

$('btnClearCookies').addEventListener('click', async () => {
  if (!confirm('Tüm çerez havuzunu temizlemek istediğinize emin misiniz?')) return;
  await api('/api/cookies/clear', 'POST', {});
  toast('Çerez havuzu temizlendi.');
});

// Proxy actions
$('btnImportProxies').addEventListener('click', async () => {
  try {
    const lines = $('proxyBulkInput').value.trim();
    if (!lines) return toast('Lütfen eklenecek proxy satırlarını girin.', true);
    const r = await api('/api/proxies/import', 'POST', { lines });
    $('proxyBulkInput').value = '';
    toast(`${r.added} adet yeni proxy eklendi.`);
  } catch (e) {
    toast(e.message, true);
  }
});

$('btnTestProxies').addEventListener('click', async () => {
  try {
    toast('Proxyler test ediliyor, lütfen bekleyin...');
    const r = await api('/api/proxies/test', 'POST', {});
    toast(`Test tamamlandı: ${r.alive} / ${r.total} proxy aktif.`);
  } catch (e) {
    toast(e.message, true);
  }
});

$('btnRemoveDeadProxies').addEventListener('click', async () => {
  await api('/api/proxies/clear', 'POST', { onlyDead: true });
  toast('Çalışmayan proxyler temizlendi.');
});

$('btnClearProxies').addEventListener('click', async () => {
  if (!confirm('Tüm proxy listesini silmek istediğinize emin misiniz?')) return;
  await api('/api/proxies/clear', 'POST', {});
  toast('Proxy listesi temizlendi.');
});

$('btnSaveRotation').addEventListener('click', async () => {
  try {
    await api('/api/settings', 'POST', {
      mobileRotationUrl: $('rotApiUrl').value.trim(),
      rotateEverySessions: Number($('rotEveryN').value) || 5,
    });
    toast('Mobil IP yenileme ayarları kaydedildi.');
  } catch (e) {
    toast(e.message, true);
  }
});

$('btnTriggerRotationNow').addEventListener('click', async () => {
  try {
    const url = $('rotApiUrl').value.trim();
    const res = await fetch('/api/proxies/rotate-ip', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url }),
    });
    const d = await res.json();
    if (d.ok) toast(`IP yenileme başarılı! (HTTP ${d.statusCode})`);
    else toast(d.error || 'IP yenileme başarısız', true);
  } catch (e) {
    toast(e.message, true);
  }
});

// Settings save
$('btnSaveSettings').addEventListener('click', async () => {
  try {
    const hourlyCurve = Array.from(document.querySelectorAll('.hour-input')).map((inp) =>
      Math.max(0, Math.min(100, Number(inp.value) || 0))
    );
    await api('/api/settings', 'POST', {
      browserPath: $('setBrowserPath').value.trim(),
      googleDomain: $('setGoogleDomain').value,
      maxGlobalConcurrency: Number($('setMaxConcurrency').value) || 4,
      defaultLocale: $('setLocale').value.trim(),
      defaultTimezone: $('setTimezone').value.trim(),
      lightweightMode: $('setLightweight').checked,
      headlessMode: $('setHeadless').checked,
      hourlyCurveEnabled: $('setHourlyEnabled').checked,
      hourlyCurve,
      cookieSeedSites: $('setSeedSites').value,
    });
    toast('Tüm sistem ayarları kaydedildi.');
  } catch (e) {
    toast(e.message, true);
  }
});

$('btnResetStats').addEventListener('click', async () => {
  if (!confirm('Genel istatistik sayaçlarını sıfırlamak istiyor musunuz?')) return;
  await api('/api/stats/reset', 'POST', {});
  toast('İstatistik sayaçları sıfırlandı.');
});

$('btnClearLogs').addEventListener('click', () => {
  $('liveLogStream').innerHTML = '';
});

// Connect SSE Live Stream
function connectLiveStream() {
  const es = new EventSource('/api/events');
  es.addEventListener('snapshot', (ev) => {
    try {
      renderSnapshot(JSON.parse(ev.data));
    } catch {}
  });
  es.addEventListener('log', (ev) => {
    try {
      appendLog(JSON.parse(ev.data));
    } catch {}
  });
  es.onerror = () => {
    es.close();
    setTimeout(connectLiveStream, 2500);
  };
}

connectLiveStream();
