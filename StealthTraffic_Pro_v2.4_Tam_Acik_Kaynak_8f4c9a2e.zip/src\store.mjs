import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { generateFingerprint } from './fingerprints.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
export const DATA_DIR = path.resolve(__dirname, '..', 'data');

const DEFAULT_SEED_SITES = [
  'https://www.google.com.tr/',
  'https://www.ntv.com.tr/',
  'https://tr.wikipedia.org/wiki/Anasayfa',
  'https://www.haberturk.com/',
  'https://www.hurriyet.com.tr/',
  'https://www.youtube.com/',
  'https://www.donanimhaber.com/',
  'https://www.ensonhaber.com/',
];

// Natural 24-hour organic traffic curve (00:00 -> 23:00 multipliers in %)
const DEFAULT_HOURLY_CURVE = [
  35, 22, 15, 12, 12, 18,
  35, 55, 78, 92, 100, 100,
  95, 98, 100, 96, 92, 88,
  85, 90, 95, 88, 68, 48,
];

const DEFAULT_STATE = {
  settings: {
    browserPath: '', // auto-detect if empty
    headlessMode: true,
    lightweightMode: true, // block heavy images/videos/fonts while keeping GA4 & JS
    maxGlobalConcurrency: 4,
    defaultLocale: 'tr-TR',
    defaultTimezone: 'Europe/Istanbul',
    googleDomain: 'https://www.google.com.tr',
    mobileRotationUrl: '',
    rotateEverySessions: 5,
    hourlyCurveEnabled: false,
    hourlyCurve: DEFAULT_HOURLY_CURVE,
    cookieSeedSites: DEFAULT_SEED_SITES,
  },
  stats: {
    totalSessions: 0,
    successfulSessions: 0,
    failedSessions: 0,
    serpClicks: 0,
    brandedSearches: 0,
    referrerHits: 0,
    directHits: 0,
    analyticsBeaconsVerified: 0,
    subpagesVisited: 0,
    blockedHeavyRequests: 0,
    savedBandwidthBytes: 0,
    cookiesGeneratedTotal: 0,
    totalDwellSeconds: 0,
  },
  campaigns: [
    {
      id: 'CMP-DEMO01',
      name: 'Örnek Google Organik & Alt Sayfa Kampanyası',
      status: 'paused',
      mode: 'serp', // 'serp' | 'branded' | 'referrer' | 'direct'
      targetDomain: 'example.com',
      targetUrls: ['https://example.com/'],
      keywords: ['example domain', 'iana example'],
      brandName: 'Example',
      referrers: [
        'https://t.co/',
        'https://l.instagram.com/',
        'https://www.youtube.com/',
        'https://www.google.com.tr/',
      ],
      targetVisits: 50,
      completedVisits: 0,
      failedVisits: 0,
      verifiedGaHits: 0,
      concurrency: 1,
      mobileRatio: 70,
      dwellMinSec: 25,
      dwellMaxSec: 55,
      subpagesMin: 1,
      subpagesMax: 3,
      maxSerpPages: 3,
      useCookiePool: true,
      autoWarmIfEmpty: true,
      lightweightMode: true,
      headlessMode: true,
      useProxies: true,
      createdAt: new Date().toISOString(),
      lastRunAt: null,
    },
  ],
  cookies: [],
  proxies: [],
};

export class AppStore {
  constructor() {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    this.stateFile = path.join(DATA_DIR, 'state.json');
    this.cookiesFile = path.join(DATA_DIR, 'cookies.json');
    this.state = this._loadState();
    this.cookies = this._loadCookies();
    this._saveTimer = null;
  }

  _loadState() {
    try {
      if (fs.existsSync(this.stateFile)) {
        const raw = JSON.parse(fs.readFileSync(this.stateFile, 'utf8'));
        const loadedCampaigns = Array.isArray(raw.campaigns) ? raw.campaigns : DEFAULT_STATE.campaigns;
        for (const c of loadedCampaigns) {
          if (c && c.status === 'running') c.status = 'paused';
        }
        return {
          settings: { ...DEFAULT_STATE.settings, ...(raw.settings || {}) },
          stats: { ...DEFAULT_STATE.stats, ...(raw.stats || {}) },
          campaigns: loadedCampaigns,
          proxies: Array.isArray(raw.proxies) ? raw.proxies : [],
        };
      }
    } catch {}
    return structuredClone({
      settings: DEFAULT_STATE.settings,
      stats: DEFAULT_STATE.stats,
      campaigns: DEFAULT_STATE.campaigns,
      proxies: [],
    });
  }

  _loadCookies() {
    try {
      if (fs.existsSync(this.cookiesFile)) {
        const arr = JSON.parse(fs.readFileSync(this.cookiesFile, 'utf8'));
        if (Array.isArray(arr)) return arr;
      }
    } catch {}
    return [];
  }

  saveNow() {
    if (this._saveTimer) {
      clearTimeout(this._saveTimer);
      this._saveTimer = null;
    }
    const tmpState = this.stateFile + '.tmp';
    fs.writeFileSync(tmpState, JSON.stringify(this.state, null, 2), 'utf8');
    fs.renameSync(tmpState, this.stateFile);

    const tmpCookies = this.cookiesFile + '.tmp';
    fs.writeFileSync(tmpCookies, JSON.stringify(this.cookies, null, 2), 'utf8');
    fs.renameSync(tmpCookies, this.cookiesFile);
  }

  scheduleSave() {
    if (this._saveTimer) return;
    this._saveTimer = setTimeout(() => this.saveNow(), 500);
  }

  // ===COOKIE POOL HELPERS===
  computeCookieMeta(cookies = [], warmupVisits = 1) {
    const domains = new Set();
    let hasGaCookie = false;
    let hasGoogleCookies = false;
    for (const c of cookies) {
      const dom = String(c.domain || '').replace(/^\./, '');
      if (dom) domains.add(dom);
      if (/^(_ga|_gid|_gat)/i.test(c.name)) hasGaCookie = true;
      if (/^(NID|AEC|SOCS|1P_JAR|CONSENT|__Secure-ENID)$/i.test(c.name) && dom.includes('google')) {
        hasGoogleCookies = true;
      }
    }
    const score = Math.min(
      100,
      Math.round(
        Math.min(cookies.length, 30) * 1.4 +
          Math.min(domains.size, 8) * 4 +
          (hasGaCookie ? 14 : 0) +
          (hasGoogleCookies ? 16 : 0) +
          Math.min(warmupVisits, 6) * 3
      )
    );
    return {
      cookieCount: cookies.length,
      domainCount: domains.size,
      domains: Array.from(domains).slice(0, 15),
      hasGaCookie,
      hasGoogleCookies,
      warmScore: score,
    };
  }

  upsertCookieProfile({ id, fingerprint, cookies, warmupVisits = 1, label = '' }) {
    const cleanCookies = (cookies || [])
      .filter((c) => c && c.name && c.domain)
      .map((c) => ({
        name: String(c.name),
        value: String(c.value ?? ''),
        domain: String(c.domain),
        path: String(c.path || '/'),
        expires: Number.isFinite(Number(c.expires)) && Number(c.expires) > 0 ? Number(c.expires) : Math.floor(Date.now() / 1000) + 86400 * 180,
        httpOnly: Boolean(c.httpOnly),
        secure: Boolean(c.secure),
        sameSite: ['Strict', 'Lax', 'None'].includes(c.sameSite) ? c.sameSite : undefined,
      }));

    const existingIdx = id ? this.cookies.findIndex((p) => p.id === id) : -1;
    const now = new Date().toISOString();

    if (existingIdx >= 0) {
      const prev = this.cookies[existingIdx];
      // Merge cookies by domain+path+name
      const mergedMap = new Map();
      for (const c of prev.cookies || []) mergedMap.set(`${c.domain}|${c.path}|${c.name}`, c);
      for (const c of cleanCookies) mergedMap.set(`${c.domain}|${c.path}|${c.name}`, c);
      const mergedCookies = Array.from(mergedMap.values());
      const visits = (prev.warmupVisits || 1) + warmupVisits;
      const meta = this.computeCookieMeta(mergedCookies, visits);
      const updated = {
        ...prev,
        ...meta,
        warmupVisits: visits,
        updatedAt: now,
        lastUsedAt: now,
        useCount: (prev.useCount || 0) + 1,
        cookies: mergedCookies,
      };
      this.cookies[existingIdx] = updated;
      this.scheduleSave();
      return updated;
    }

    const fp = fingerprint || generateFingerprint({ deviceType: 'auto' });
    const profileId = id || 'CK-' + crypto.randomBytes(3).toString('hex').toUpperCase();
    const meta = this.computeCookieMeta(cleanCookies, warmupVisits);
    const created = {
      id: profileId,
      label: label || fp.label,
      deviceType: fp.deviceType,
      fingerprint: fp,
      ...meta,
      warmupVisits,
      useCount: 0,
      createdAt: now,
      updatedAt: now,
      lastUsedAt: null,
      cookies: cleanCookies,
    };
    this.cookies.unshift(created);
    this.state.stats.cookiesGeneratedTotal = (this.state.stats.cookiesGeneratedTotal || 0) + 1;
    this.scheduleSave();
    return created;
  }

  pickWarmCookieProfile(preferMobile = null) {
    if (!this.cookies.length) return null;
    let candidates = this.cookies.filter(
      (c) => (c.cookies?.length || 0) > 0 && c.fingerprint?.uaPlatform !== 'iOS'
    );
    if (!candidates.length) return null;
    if (preferMobile !== null) {
      const targetType = preferMobile ? 'mobile' : 'desktop';
      const typed = candidates.filter((c) => c.deviceType === targetType);
      if (typed.length) candidates = typed;
    }
    // Sort by least recently used + higher warmScore
    candidates.sort((a, b) => {
      const ta = a.lastUsedAt ? new Date(a.lastUsedAt).getTime() : 0;
      const tb = b.lastUsedAt ? new Date(b.lastUsedAt).getTime() : 0;
      if (ta !== tb) return ta - tb;
      return (b.warmScore || 0) - (a.warmScore || 0);
    });
    return candidates[0];
  }

  exportNetscape(profileId = null) {
    const lines = [
      '# Netscape HTTP Cookie File',
      '# Generated by StealthTraffic Pro Cookie Pool',
      '',
    ];
    const list = profileId ? this.cookies.filter((p) => p.id === profileId) : this.cookies;
    for (const p of list) {
      lines.push(`# Profile: ${p.id} (${p.label} | Score: ${p.warmScore})`);
      for (const c of p.cookies || []) {
        const domain = c.domain.startsWith('.') ? c.domain : '.' + c.domain;
        const includeSubdomains = 'TRUE';
        const cookiePath = c.path || '/';
        const secure = c.secure ? 'TRUE' : 'FALSE';
        const expiry = Math.max(0, Math.floor(Number(c.expires) || Math.floor(Date.now() / 1000) + 86400 * 90));
        lines.push(`${domain}\t${includeSubdomains}\t${cookiePath}\t${secure}\t${expiry}\t${c.name}\t${c.value}`);
      }
      lines.push('');
    }
    return lines.join('\n');
  }

  importCookiesPayload(rawText, deviceType = 'auto') {
    const trimmed = String(rawText || '').trim();
    if (!trimmed) return { importedProfiles: 0, totalCookies: 0 };

    // 1. Try JSON (either full profile array or EditThisCookie array)
    if (trimmed.startsWith('[') || trimmed.startsWith('{')) {
      const parsed = JSON.parse(trimmed);
      const arr = Array.isArray(parsed) ? parsed : [parsed];
      if (arr.length && Array.isArray(arr[0]?.cookies)) {
        let count = 0;
        let ckTotal = 0;
        for (const prof of arr) {
          const p = this.upsertCookieProfile({
            fingerprint: prof.fingerprint || generateFingerprint({ deviceType }),
            cookies: prof.cookies,
            warmupVisits: prof.warmupVisits || 2,
            label: prof.label || 'İçe Aktarılan Profil',
          });
          count++;
          ckTotal += p.cookieCount;
        }
        this.saveNow();
        return { importedProfiles: count, totalCookies: ckTotal };
      }

      // Single EditThisCookie / Cookie-Editor JSON array
      const cookies = arr
        .filter((c) => c && c.name && c.domain)
        .map((c) => ({
          name: c.name,
          value: c.value,
          domain: c.domain,
          path: c.path || '/',
          expires: c.expirationDate || c.expires || Math.floor(Date.now() / 1000) + 86400 * 120,
          httpOnly: Boolean(c.httpOnly),
          secure: Boolean(c.secure),
        }));
      const p = this.upsertCookieProfile({
        fingerprint: generateFingerprint({ deviceType }),
        cookies,
        warmupVisits: 2,
        label: 'JSON İçe Aktarılan Çerez',
      });
      this.saveNow();
      return { importedProfiles: 1, totalCookies: p.cookieCount };
    }

    // 2. Parse Netscape HTTP Cookie format
    const cookies = [];
    for (const line of trimmed.split(/\r?\n/)) {
      const l = line.trim();
      if (!l || (l.startsWith('#') && !l.startsWith('#HttpOnly_'))) continue;
      let httpOnly = false;
      let clean = l;
      if (clean.startsWith('#HttpOnly_')) {
        httpOnly = true;
        clean = clean.slice('#HttpOnly_'.length);
      }
      const cols = clean.split('\t');
      if (cols.length >= 7) {
        cookies.push({
          domain: cols[0],
          path: cols[2] || '/',
          secure: cols[3].toUpperCase() === 'TRUE',
          expires: Number(cols[4]) || Math.floor(Date.now() / 1000) + 86400 * 120,
          name: cols[5],
          value: cols.slice(6).join('\t'),
          httpOnly,
        });
      }
    }

    if (!cookies.length) {
      throw new Error('Geçerli JSON veya Netscape formatında çerez kaydı bulunamadı.');
    }

    const p = this.upsertCookieProfile({
      fingerprint: generateFingerprint({ deviceType }),
      cookies,
      warmupVisits: 2,
      label: 'Netscape İçe Aktarılan Çerez',
    });
    this.saveNow();
    return { importedProfiles: 1, totalCookies: p.cookieCount };
  }
}
