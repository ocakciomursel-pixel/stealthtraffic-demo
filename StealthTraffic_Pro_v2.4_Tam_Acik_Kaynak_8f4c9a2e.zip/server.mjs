import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { AppStore } from './src/store.mjs';
import { detectBrowserExecutable } from './src/cdp-client.mjs';
import { parseProxyLine, testProxyConnectivity, triggerMobileIpRotation } from './src/proxy-manager.mjs';
import { TrafficOrchestrator } from './src/traffic-engine.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC_DIR = path.join(__dirname, 'public');
const PORT = Number(process.env.PORT) || 3850;
const HOST = process.env.HOST || '127.0.0.1';

const store = new AppStore();
const engine = new TrafficOrchestrator(store);

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
};

function sendJson(res, status, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
  });
  res.end(body);
}

function readJsonBody(req) {
  return new Promise((resolve, reject) => {
    let raw = '';
    req.on('data', (chunk) => {
      raw += chunk;
      if (raw.length > 15 * 1024 * 1024) {
        req.destroy();
        reject(new Error('İstek gövdesi çok büyük.'));
      }
    });
    req.on('end', () => {
      if (!raw.trim()) return resolve({});
      try {
        resolve(JSON.parse(raw));
      } catch {
        reject(new Error('Geçersiz JSON formatı.'));
      }
    });
    req.on('error', reject);
  });
}

// SSE Live Stream Subscribers
const sseClients = new Set();

function broadcastSse(event, data) {
  const frame = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
  for (const client of sseClients) {
    try {
      client.write(frame);
    } catch {
      sseClients.delete(client);
    }
  }
}

engine.on('log', (entry) => broadcastSse('log', entry));

let tickTimer = null;
engine.on('state_tick', () => {
  if (tickTimer) return;
  tickTimer = setTimeout(() => {
    tickTimer = null;
    broadcastSse('snapshot', buildDashboardPayload());
  }, 250);
});

function buildDashboardPayload() {
  const detectedBrowser = detectBrowserExecutable(store.state.settings.browserPath);
  return {
    settings: store.state.settings,
    detectedBrowser,
    stats: store.state.stats,
    campaigns: store.state.campaigns,
    cookieSummary: {
      totalProfiles: store.cookies.length,
      gaReadyCount: store.cookies.filter((c) => c.hasGaCookie).length,
      googleReadyCount: store.cookies.filter((c) => c.hasGoogleCookies).length,
      avgScore: store.cookies.length
        ? Math.round(store.cookies.reduce((acc, c) => acc + (c.warmScore || 0), 0) / store.cookies.length)
        : 0,
      profiles: store.cookies.map((c) => ({
        id: c.id,
        label: c.label,
        deviceType: c.deviceType,
        cookieCount: c.cookieCount,
        domainCount: c.domainCount,
        domains: c.domains,
        hasGaCookie: c.hasGaCookie,
        hasGoogleCookies: c.hasGoogleCookies,
        warmScore: c.warmScore,
        warmupVisits: c.warmupVisits,
        useCount: c.useCount,
        createdAt: c.createdAt,
        lastUsedAt: c.lastUsedAt,
      })),
    },
    proxies: store.state.proxies,
    runtime: engine.getSnapshot(),
  };
}

const server = http.createServer(async (req, res) => {
  try {
    const u = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    const pathname = u.pathname;
    const method = req.method;

    // 1. SSE Endpoint
    if (method === 'GET' && pathname === '/api/events') {
      res.writeHead(200, {
        'Content-Type': 'text/event-stream; charset=utf-8',
        'Cache-Control': 'no-cache, no-transform',
        Connection: 'keep-alive',
      });
      res.write(`event: snapshot\ndata: ${JSON.stringify(buildDashboardPayload())}\n\n`);
      for (const l of engine.recentLogs.slice(-60)) {
        res.write(`event: log\ndata: ${JSON.stringify(l)}\n\n`);
      }
      sseClients.add(res);
      req.on('close', () => sseClients.delete(res));
      return;
    }

    // 2. Dashboard State
    if (method === 'GET' && pathname === '/api/state') {
      return sendJson(res, 200, { ok: true, ...buildDashboardPayload(), logs: engine.recentLogs.slice(-80) });
    }

    // 3. Quick 1-Click Live Demo
    if (method === 'POST' && pathname === '/api/demo/start') {
      const body = await readJsonBody(req);
      const camp = await engine.startQuickLiveDemo(body);
      return sendJson(res, 200, { ok: true, campaign: camp });
    }

    // 4. Campaigns CRUD & Controls
    if (method === 'POST' && pathname === '/api/campaigns') {
      const b = await readJsonBody(req);
      const id = b.id || 'CMP-' + crypto.randomBytes(3).toString('hex').toUpperCase();
      const targetUrls = Array.isArray(b.targetUrls)
        ? b.targetUrls
        : String(b.targetUrls || '')
            .split(/\r?\n/)
            .map((s) => s.trim())
            .filter(Boolean);
      const keywords = Array.isArray(b.keywords)
        ? b.keywords
        : String(b.keywords || '')
            .split(/\r?\n/)
            .map((s) => s.trim())
            .filter(Boolean);
      const referrers = Array.isArray(b.referrers)
        ? b.referrers
        : String(b.referrers || '')
            .split(/\r?\n/)
            .map((s) => s.trim())
            .filter(Boolean);

      const existingIdx = store.state.campaigns.findIndex((c) => c.id === id);
      const record = {
        id,
        name: String(b.name || 'Yeni Trafik Kampanyası').trim(),
        status: existingIdx >= 0 ? store.state.campaigns[existingIdx].status : 'paused',
        mode: ['serp', 'branded', 'referrer', 'direct'].includes(b.mode) ? b.mode : 'serp',
        targetDomain: String(b.targetDomain || targetUrls[0] || '').trim(),
        targetUrls: targetUrls.length ? targetUrls : [String(b.targetDomain || 'https://example.com').trim()],
        keywords,
        brandName: String(b.brandName || '').trim(),
        referrers: referrers.length
          ? referrers
          : ['https://www.google.com.tr/', 'https://t.co/', 'https://l.instagram.com/'],
        targetVisits: Math.max(0, Number(b.targetVisits) || 100),
        completedVisits: existingIdx >= 0 ? store.state.campaigns[existingIdx].completedVisits : 0,
        failedVisits: existingIdx >= 0 ? store.state.campaigns[existingIdx].failedVisits : 0,
        verifiedGaHits: existingIdx >= 0 ? store.state.campaigns[existingIdx].verifiedGaHits : 0,
        concurrency: Math.max(1, Math.min(16, Number(b.concurrency) || 2)),
        mobileRatio: Math.max(0, Math.min(100, Number(b.mobileRatio ?? 70))),
        dwellMinSec: Math.max(5, Number(b.dwellMinSec) || 30),
        dwellMaxSec: Math.max(10, Number(b.dwellMaxSec) || 75),
        subpagesMin: Math.max(0, Number(b.subpagesMin ?? 1)),
        subpagesMax: Math.max(0, Number(b.subpagesMax ?? 3)),
        maxSerpPages: Math.max(1, Math.min(10, Number(b.maxSerpPages) || 3)),
        useCookiePool: b.useCookiePool !== false,
        autoWarmIfEmpty: b.autoWarmIfEmpty !== false,
        lightweightMode: b.lightweightMode !== false,
        headlessMode: b.headlessMode !== false,
        useProxies: Boolean(b.useProxies),
        createdAt: existingIdx >= 0 ? store.state.campaigns[existingIdx].createdAt : new Date().toISOString(),
        lastRunAt: existingIdx >= 0 ? store.state.campaigns[existingIdx].lastRunAt : null,
      };

      if (existingIdx >= 0) store.state.campaigns[existingIdx] = record;
      else store.state.campaigns.unshift(record);
      store.saveNow();
      broadcastSse('snapshot', buildDashboardPayload());
      return sendJson(res, 200, { ok: true, campaign: record });
    }

    // 4b. Bulk Multi-Domain & Keyword Matrix Import (domain | kw1, kw2, kw3)
    if (method === 'POST' && pathname === '/api/campaigns/bulk') {
      const b = await readJsonBody(req);
      const lines = String(b.lines || '')
        .split(/\r?\n/)
        .map((s) => s.trim())
        .filter((s) => s && !s.startsWith('#'));
      if (!lines.length) {
        return sendJson(res, 400, { ok: false, error: 'Lütfen en az 1 adet domain | kelime satırı girin.' });
      }
      const mode = ['serp', 'branded', 'referrer', 'direct'].includes(b.mode) ? b.mode : 'serp';
      const visitsPerDomain = Math.max(1, Number(b.targetVisits) || 100);
      const concurrency = Math.max(1, Math.min(8, Number(b.concurrency) || 2));
      const autoStart = b.autoStart !== false;
      const created = [];

      for (const line of lines) {
        const [rawTarget, rawKws = ''] = line.split(/[|;]/);
        const cleanTarget = (rawTarget || '').trim();
        if (!cleanTarget) continue;
        const fullUrl = /^https?:\/\//i.test(cleanTarget) ? cleanTarget : `https://${cleanTarget}/`;
        const domainOnly = fullUrl.replace(/^https?:\/\//i, '').split('/')[0];
        const keywords = rawKws
          .split(',')
          .map((k) => k.trim())
          .filter(Boolean);
        const id = 'CMP-' + crypto.randomBytes(3).toString('hex').toUpperCase();
        const record = {
          id,
          name: `Toplu: ${domainOnly}` + (keywords.length ? ` (${keywords.length} kelime)` : ''),
          status: 'paused',
          mode: keywords.length ? mode : 'direct',
          targetDomain: domainOnly,
          targetUrls: [fullUrl],
          keywords,
          brandName: domainOnly.split('.')[0],
          referrers: ['https://www.google.com.tr/', 'https://t.co/', 'https://l.instagram.com/'],
          targetVisits: visitsPerDomain,
          completedVisits: 0,
          failedVisits: 0,
          verifiedGaHits: 0,
          concurrency,
          mobileRatio: 75,
          dwellMinSec: Math.max(5, Number(b.dwellMinSec) || 35),
          dwellMaxSec: Math.max(10, Number(b.dwellMaxSec) || 75),
          subpagesMin: 1,
          subpagesMax: 3,
          maxSerpPages: 3,
          useCookiePool: true,
          autoWarmIfEmpty: true,
          lightweightMode: true,
          headlessMode: true,
          useProxies: Boolean(b.useProxies),
          createdAt: new Date().toISOString(),
          lastRunAt: null,
        };
        store.state.campaigns.unshift(record);
        if (autoStart) {
          engine.startCampaign(id);
        }
        created.push(record);
      }

      store.saveNow();
      broadcastSse('snapshot', buildDashboardPayload());
      return sendJson(res, 200, { ok: true, count: created.length, campaigns: created });
    }

    const campActionMatch = pathname.match(/^\/api\/campaigns\/([^/]+)\/(start|pause|reset|delete)$/);
    if (method === 'POST' && campActionMatch) {
      const [, id, action] = campActionMatch;
      if (action === 'start') {
        const camp = engine.startCampaign(id);
        return sendJson(res, 200, { ok: true, campaign: camp });
      }
      if (action === 'pause') {
        const camp = engine.pauseCampaign(id);
        return sendJson(res, 200, { ok: true, campaign: camp });
      }
      if (action === 'reset') {
        engine.pauseCampaign(id);
        const camp = store.state.campaigns.find((c) => c.id === id);
        if (camp) {
          camp.completedVisits = 0;
          camp.failedVisits = 0;
          camp.verifiedGaHits = 0;
          camp.status = 'paused';
          store.saveNow();
        }
        broadcastSse('snapshot', buildDashboardPayload());
        return sendJson(res, 200, { ok: true, campaign: camp });
      }
      if (action === 'delete') {
        engine.pauseCampaign(id);
        store.state.campaigns = store.state.campaigns.filter((c) => c.id !== id);
        store.saveNow();
        broadcastSse('snapshot', buildDashboardPayload());
        return sendJson(res, 200, { ok: true });
      }
    }

    // 5. Cookie Pool Endpoints
    if (method === 'POST' && pathname === '/api/cookies/warmup') {
      const body = await readJsonBody(req);
      const job = await engine.startCookieWarmupJob(body);
      return sendJson(res, 200, { ok: true, job });
    }

    if (method === 'POST' && pathname === '/api/cookies/stop') {
      engine.stopCookieWarmupJob();
      return sendJson(res, 200, { ok: true });
    }

    if (method === 'POST' && pathname === '/api/cookies/import') {
      const body = await readJsonBody(req);
      const result = store.importCookiesPayload(body.payload, body.deviceType || 'auto');
      engine.log('success', 'ÇEREZ-HAVUZU', `İçe aktarım tamamlandı: ${result.importedProfiles} profil (${result.totalCookies} çerez).`);
      broadcastSse('snapshot', buildDashboardPayload());
      return sendJson(res, 200, { ok: true, ...result });
    }

    if (method === 'GET' && pathname === '/api/cookies/export') {
      const format = u.searchParams.get('format') || 'netscape';
      const profileId = u.searchParams.get('id') || null;
      if (format === 'json') {
        const data = profileId ? store.cookies.filter((p) => p.id === profileId) : store.cookies;
        res.writeHead(200, {
          'Content-Type': 'application/json; charset=utf-8',
          'Content-Disposition': `attachment; filename="cookies-${profileId || 'pool'}.json"`,
        });
        return res.end(JSON.stringify(data, null, 2));
      }
      const txt = store.exportNetscape(profileId);
      res.writeHead(200, {
        'Content-Type': 'text/plain; charset=utf-8',
        'Content-Disposition': `attachment; filename="cookies-${profileId || 'pool'}-netscape.txt"`,
      });
      return res.end(txt);
    }

    if (method === 'POST' && pathname === '/api/cookies/clear') {
      const body = await readJsonBody(req);
      if (body.id) {
        store.cookies = store.cookies.filter((c) => c.id !== body.id);
      } else {
        store.cookies = [];
      }
      store.saveNow();
      broadcastSse('snapshot', buildDashboardPayload());
      return sendJson(res, 200, { ok: true });
    }

    // 6. Proxy Pool Endpoints
    if (method === 'POST' && pathname === '/api/proxies/import') {
      const body = await readJsonBody(req);
      const lines = String(body.lines || '').split(/\r?\n/);
      let added = 0;
      const existingIds = new Set(store.state.proxies.map((p) => p.id));
      for (const l of lines) {
        const parsed = parseProxyLine(l);
        if (parsed && !existingIds.has(parsed.id)) {
          store.state.proxies.push(parsed);
          existingIds.add(parsed.id);
          added++;
        }
      }
      store.saveNow();
      engine.log('info', 'PROXY-HAVUZU', `${added} adet yeni proxy havuza eklendi.`);
      broadcastSse('snapshot', buildDashboardPayload());
      return sendJson(res, 200, { ok: true, added, total: store.state.proxies.length });
    }

    if (method === 'POST' && pathname === '/api/proxies/test') {
      const proxies = store.state.proxies;
      let alive = 0;
      await Promise.all(
        proxies.map(async (p) => {
          const check = await testProxyConnectivity(p, 5500);
          p.latencyMs = check.latencyMs;
          p.exitIp = check.exitIp;
          p.status = check.ok ? 'active' : 'dead';
          if (check.ok) alive++;
        })
      );
      store.saveNow();
      engine.log('success', 'PROXY-HAVUZU', `Proxy sağlık testi tamamlandı: ${alive}/${proxies.length} aktif.`);
      broadcastSse('snapshot', buildDashboardPayload());
      return sendJson(res, 200, { ok: true, alive, total: proxies.length });
    }

    if (method === 'POST' && pathname === '/api/proxies/rotate-ip') {
      const body = await readJsonBody(req);
      const url = body.url || store.state.settings.mobileRotationUrl;
      const r = await triggerMobileIpRotation(url);
      if (r.ok) engine.log('success', 'PROXY-HAVUZU', `Mobil IP yenileme başarılı (HTTP ${r.statusCode}).`);
      else engine.log('warn', 'PROXY-HAVUZU', `Mobil IP yenileme hatası: ${r.error || r.statusCode}`);
      return sendJson(res, 200, r);
    }

    if (method === 'POST' && pathname === '/api/proxies/clear') {
      const body = await readJsonBody(req);
      if (body.onlyDead) {
        store.state.proxies = store.state.proxies.filter((p) => p.status !== 'dead');
      } else if (body.id) {
        store.state.proxies = store.state.proxies.filter((p) => p.id !== body.id);
      } else {
        store.state.proxies = [];
      }
      store.saveNow();
      broadcastSse('snapshot', buildDashboardPayload());
      return sendJson(res, 200, { ok: true });
    }

    // 7. Settings & Stats Reset
    if (method === 'POST' && pathname === '/api/settings') {
      const body = await readJsonBody(req);
      const s = store.state.settings;
      if (typeof body.browserPath === 'string') s.browserPath = body.browserPath.trim();
      if (typeof body.headlessMode === 'boolean') s.headlessMode = body.headlessMode;
      if (typeof body.lightweightMode === 'boolean') s.lightweightMode = body.lightweightMode;
      if (body.maxGlobalConcurrency !== undefined) s.maxGlobalConcurrency = Math.max(1, Math.min(20, Number(body.maxGlobalConcurrency) || 4));
      if (typeof body.defaultLocale === 'string') s.defaultLocale = body.defaultLocale.trim() || 'tr-TR';
      if (typeof body.defaultTimezone === 'string') s.defaultTimezone = body.defaultTimezone.trim() || 'Europe/Istanbul';
      if (typeof body.googleDomain === 'string') s.googleDomain = body.googleDomain.trim() || 'https://www.google.com.tr';
      if (typeof body.mobileRotationUrl === 'string') s.mobileRotationUrl = body.mobileRotationUrl.trim();
      if (body.rotateEverySessions !== undefined) s.rotateEverySessions = Math.max(1, Number(body.rotateEverySessions) || 5);
      if (typeof body.hourlyCurveEnabled === 'boolean') s.hourlyCurveEnabled = body.hourlyCurveEnabled;
      if (Array.isArray(body.hourlyCurve) && body.hourlyCurve.length === 24) {
        s.hourlyCurve = body.hourlyCurve.map((v) => Math.max(0, Math.min(100, Number(v) || 0)));
      }
      if (body.cookieSeedSites !== undefined) {
        const list = Array.isArray(body.cookieSeedSites)
          ? body.cookieSeedSites
          : String(body.cookieSeedSites)
              .split(/\r?\n/)
              .map((x) => x.trim())
              .filter(Boolean);
        if (list.length) s.cookieSeedSites = list;
      }
      store.saveNow();
      engine.log('success', 'AYARLAR', 'Sistem ve Stealth tarayıcı ayarları kaydedildi.');
      broadcastSse('snapshot', buildDashboardPayload());
      return sendJson(res, 200, { ok: true, settings: s });
    }

    if (method === 'POST' && pathname === '/api/stats/reset') {
      for (const k of Object.keys(store.state.stats)) store.state.stats[k] = 0;
      store.saveNow();
      broadcastSse('snapshot', buildDashboardPayload());
      return sendJson(res, 200, { ok: true });
    }

    // 8. Static UI Files
    let relPath = pathname === '/' ? '/index.html' : pathname;
    const safePath = path.normalize(path.join(PUBLIC_DIR, relPath));
    if (!safePath.startsWith(PUBLIC_DIR)) {
      res.writeHead(403);
      return res.end('Forbidden');
    }
    if (fs.existsSync(safePath) && fs.statSync(safePath).isFile()) {
      const ext = path.extname(safePath).toLowerCase();
      res.writeHead(200, {
        'Content-Type': MIME_TYPES[ext] || 'application/octet-stream',
        'Cache-Control': 'no-cache',
      });
      return fs.createReadStream(safePath).pipe(res);
    }

    sendJson(res, 404, { ok: false, error: 'Endpoint bulunamadı.' });
  } catch (err) {
    sendJson(res, 400, { ok: false, error: err.message || 'Sunucu hatası' });
  }
});

server.listen(PORT, HOST, () => {
  const browserBin = detectBrowserExecutable(store.state.settings.browserPath);
  console.log('===============================================================');
  console.log('  StealthTraffic Pro — Hafifletilmis Gercek Tarayici & Cookie  ');
  console.log(`  Yonetim Paneli : http://${HOST}:${PORT}`);
  console.log(`  Tarayici Motoru: ${browserBin || 'Bulunamadi (Ayarlardan secin)'}`);
  console.log('===============================================================');
});

function shutdown() {
  try {
    store.saveNow();
    server.close();
  } catch {}
  setTimeout(() => process.exit(0), 250);
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
