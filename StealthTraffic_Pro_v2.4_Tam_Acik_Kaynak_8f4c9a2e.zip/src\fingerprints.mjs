import crypto from 'node:crypto';

const MOBILE_PRESETS = [
  {
    label: 'Samsung Galaxy S24 (Android 14)',
    deviceType: 'mobile',
    userAgent:
      'Mozilla/5.0 (Linux; Android 14; SM-S921B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.6778.135 Mobile Safari/537.36',
    platform: 'Linux armv81',
    uaPlatform: 'Android',
    uaPlatformVersion: '14.0.0',
    uaModel: 'SM-S921B',
    mobile: true,
    width: 384,
    height: 832,
    deviceScaleFactor: 2.8125,
    hardwareConcurrency: 8,
    deviceMemory: 8,
    maxTouchPoints: 5,
    webglVendor: 'Qualcomm',
    webglRenderer: 'Adreno (TM) 750',
  },
  {
    label: 'Google Pixel 8 Pro (Android 14)',
    deviceType: 'mobile',
    userAgent:
      'Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.6778.108 Mobile Safari/537.36',
    platform: 'Linux armv81',
    uaPlatform: 'Android',
    uaPlatformVersion: '14.0.0',
    uaModel: 'Pixel 8 Pro',
    mobile: true,
    width: 412,
    height: 892,
    deviceScaleFactor: 2.625,
    hardwareConcurrency: 8,
    deviceMemory: 8,
    maxTouchPoints: 5,
    webglVendor: 'ARM',
    webglRenderer: 'Mali-G715-Immortalis MC7',
  },
  {
    label: 'Xiaomi Redmi Note 13 Pro (Android 14)',
    deviceType: 'mobile',
    userAgent:
      'Mozilla/5.0 (Linux; Android 14; 2312DRA50G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.6723.107 Mobile Safari/537.36',
    platform: 'Linux armv81',
    uaPlatform: 'Android',
    uaPlatformVersion: '14.0.0',
    uaModel: '2312DRA50G',
    mobile: true,
    width: 393,
    height: 873,
    deviceScaleFactor: 2.75,
    hardwareConcurrency: 8,
    deviceMemory: 8,
    maxTouchPoints: 5,
    webglVendor: 'Qualcomm',
    webglRenderer: 'Adreno (TM) 710',
  },
  {
    label: 'Samsung Galaxy A55 5G (Android 14)',
    deviceType: 'mobile',
    userAgent:
      'Mozilla/5.0 (Linux; Android 14; SM-A556E) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.6778.135 Mobile Safari/537.36',
    platform: 'Linux armv81',
    uaPlatform: 'Android',
    uaPlatformVersion: '14.0.0',
    uaModel: 'SM-A556E',
    mobile: true,
    width: 390,
    height: 844,
    deviceScaleFactor: 2.75,
    hardwareConcurrency: 8,
    deviceMemory: 8,
    maxTouchPoints: 5,
    webglVendor: 'ARM',
    webglRenderer: 'Mali-G68 MP5',
  },
];

const DESKTOP_PRESETS = [
  {
    label: 'Windows 11 Masaüstü (RTX 3060)',
    deviceType: 'desktop',
    userAgent:
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
    platform: 'Win32',
    uaPlatform: 'Windows',
    uaPlatformVersion: '15.0.0',
    uaModel: '',
    mobile: false,
    width: 1920,
    height: 1080,
    deviceScaleFactor: 1,
    hardwareConcurrency: 12,
    deviceMemory: 8,
    maxTouchPoints: 0,
    webglVendor: 'Google Inc. (NVIDIA)',
    webglRenderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 Direct3D11 vs_5_0 ps_5_0, D3D11)',
  },
  {
    label: 'Windows 11 Dizüstü (Intel Iris Xe)',
    deviceType: 'desktop',
    userAgent:
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
    platform: 'Win32',
    uaPlatform: 'Windows',
    uaPlatformVersion: '15.0.0',
    uaModel: '',
    mobile: false,
    width: 1536,
    height: 864,
    deviceScaleFactor: 1.25,
    hardwareConcurrency: 8,
    deviceMemory: 8,
    maxTouchPoints: 0,
    webglVendor: 'Google Inc. (Intel)',
    webglRenderer: 'ANGLE (Intel, Intel(R) Iris(R) Xe Graphics Direct3D11 vs_5_0 ps_5_0, D3D11)',
  },
  {
    label: 'macOS Sonoma (Apple M2)',
    deviceType: 'desktop',
    userAgent:
      'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
    platform: 'MacIntel',
    uaPlatform: 'macOS',
    uaPlatformVersion: '14.6.1',
    uaModel: '',
    mobile: false,
    width: 1440,
    height: 900,
    deviceScaleFactor: 2,
    hardwareConcurrency: 8,
    deviceMemory: 8,
    maxTouchPoints: 0,
    webglVendor: 'Google Inc. (Apple)',
    webglRenderer: 'ANGLE (Apple, ANGLE Metal Renderer: Apple M2, Unspecified Version)',
  },
];

export function generateFingerprint({ deviceType = 'auto', mobileRatio = 70, locale = 'tr-TR', timezone = 'Europe/Istanbul' } = {}) {
  let pickMobile = deviceType === 'mobile';
  if (deviceType === 'auto') {
    pickMobile = Math.random() * 100 < Number(mobileRatio ?? 70);
  }
  const pool = pickMobile ? MOBILE_PRESETS : DESKTOP_PRESETS;
  const base = pool[Math.floor(Math.random() * pool.length)];

  // Slight natural viewport jitter on desktop window sizes
  const widthJitter = base.mobile ? 0 : Math.floor((Math.random() - 0.5) * 24) * 2;
  const heightJitter = base.mobile ? 0 : Math.floor((Math.random() - 0.5) * 16) * 2;
  const noiseSeed = crypto.randomInt(100000, 999999);

  return {
    ...base,
    viewportWidth: Math.max(360, base.width + widthJitter),
    viewportHeight: Math.max(640, base.height + heightJitter),
    locale,
    acceptLanguage: locale.startsWith('tr') ? 'tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7' : `${locale},en-US;q=0.9,en;q=0.8`,
    timezone,
    noiseSeed,
  };
}

/**
 * Generates the main-world preload script registered via Page.addScriptToEvaluateOnNewDocument.
 * Executes BEFORE any site script runs on every document navigation without needing Runtime.enable.
 */
export function buildStealthInitScript(fp) {
  const cfg = JSON.stringify({
    platform: fp.platform,
    hardwareConcurrency: fp.hardwareConcurrency,
    deviceMemory: fp.deviceMemory,
    maxTouchPoints: fp.maxTouchPoints,
    webglVendor: fp.webglVendor,
    webglRenderer: fp.webglRenderer,
    languages: fp.locale.startsWith('tr') ? ['tr-TR', 'tr', 'en-US', 'en'] : [fp.locale, 'en-US', 'en'],
    mobile: fp.mobile,
    width: fp.viewportWidth,
    height: fp.viewportHeight,
    dpr: fp.deviceScaleFactor,
    seed: fp.noiseSeed || 481516,
  });

  return `(() => {
    const C = ${cfg};
    try {
      // 1. Eliminate navigator.webdriver & automation traces
      Object.defineProperty(Navigator.prototype, 'webdriver', {
        get: () => false,
        configurable: true
      });
      for (const k of Object.keys(window)) {
        if (/^(cdc_|\\$cdc_|__webdriver|__selenium|__driver|__playwright|__puppeteer)/.test(k)) {
          try { delete window[k]; } catch {}
        }
      }

      // 2. Consistent Navigator properties
      const defNav = (prop, val) => {
        try {
          Object.defineProperty(Navigator.prototype, prop, { get: () => val, configurable: true });
        } catch {}
      };
      defNav('platform', C.platform);
      defNav('hardwareConcurrency', C.hardwareConcurrency);
      defNav('deviceMemory', C.deviceMemory);
      defNav('maxTouchPoints', C.maxTouchPoints);
      defNav('languages', Object.freeze([...C.languages]));
      defNav('language', C.languages[0]);

      // 3. Realistic window.chrome object
      if (!window.chrome) window.chrome = {};
      if (!window.chrome.runtime) {
        window.chrome.runtime = {
          PlatformOs: { MAC: 'mac', WIN: 'win', ANDROID: 'android', CROS: 'cros', LINUX: 'linux', OPENBSD: 'openbsd' },
          PlatformArch: { ARM: 'arm', X86_32: 'x86-32', X86_64: 'x86-64', MIPS: 'mips', MIPS64: 'mips64' }
        };
      }
      if (!window.chrome.app) {
        window.chrome.app = { isInstalled: false, InstallState: { DISABLED: 'disabled', INSTALLED: 'installed', NOT_INSTALLED: 'not_installed' } };
      }

      // 4. Screen & outer window consistency
      const defScr = (prop, val) => {
        try {
          Object.defineProperty(Screen.prototype, prop, { get: () => val, configurable: true });
        } catch {}
      };
      defScr('width', C.width);
      defScr('height', C.height);
      defScr('availWidth', C.width);
      defScr('availHeight', C.mobile ? C.height : Math.max(600, C.height - 40));
      defScr('colorDepth', 24);
      defScr('pixelDepth', 24);
      try {
        Object.defineProperty(window, 'outerWidth', { get: () => C.width, configurable: true });
        Object.defineProperty(window, 'outerHeight', { get: () => C.mobile ? C.height : C.height + 85, configurable: true });
      } catch {}

      // 5. Permissions query consistency
      if (navigator.permissions && navigator.permissions.query) {
        const origQuery = navigator.permissions.query.bind(navigator.permissions);
        navigator.permissions.query = (params) => {
          if (params && params.name === 'notifications') {
            return Promise.resolve({ state: Notification.permission, onchange: null });
          }
          return origQuery(params);
        };
      }

      // 6. WebGL Vendor & Renderer spoofing
      const patchWebGL = (Proto) => {
        if (!Proto || !Proto.prototype || !Proto.prototype.getParameter) return;
        const origGetParam = Proto.prototype.getParameter;
        Proto.prototype.getParameter = function(param) {
          if (param === 37445) return C.webglVendor;
          if (param === 37446) return C.webglRenderer;
          return origGetParam.apply(this, arguments);
        };
      };
      patchWebGL(window.WebGLRenderingContext);
      patchWebGL(window.WebGL2RenderingContext);

      // 7. Subtle deterministic Canvas fingerprint noise (per profile seed)
      if (window.HTMLCanvasElement && HTMLCanvasElement.prototype.toDataURL) {
        const origToDataURL = HTMLCanvasElement.prototype.toDataURL;
        HTMLCanvasElement.prototype.toDataURL = function() {
          try {
            const ctx = this.getContext && this.getContext('2d');
            if (ctx && this.width > 8 && this.height > 8) {
              const img = ctx.getImageData(0, 0, 2, 2);
              img.data[0] = (img.data[0] + (C.seed % 3)) & 255;
              ctx.putImageData(img, 0, 0);
            }
          } catch {}
          return origToDataURL.apply(this, arguments);
        };
      }
    } catch {}
  })();`;
}
